define('modules/oauth-imap/views/inbound-email/record/edit', ['views/inbound-email/record/edit'], function (EditView) {
    'use strict';

    function appendOauthPanel(layout) {
        if (!Array.isArray(layout)) {
            return;
        }

        var hasPanel = layout.some(function (panel) {
            return panel && panel.name === 'oauth';
        });

        if (hasPanel) {
            return;
        }

        layout.push({
            name: 'oauth',
            label: 'OAuth IMAP',
            rows: [
                [{ name: 'oauthProvider' }, { name: 'oauthEmail' }],
                [{ name: 'oauthClientId' }, { name: 'oauthClientSecret' }],
                [{ name: 'oauthTenantId' }, { name: 'oauthScopes' }]
            ]
        });
    }

    return EditView.extend({
        setup: function () {
            EditView.prototype.setup.call(this);
        },

        modifyDetailLayout: function (layout) {
            if (EditView.prototype.modifyDetailLayout) {
                EditView.prototype.modifyDetailLayout.call(this, layout);
            }

            appendOauthPanel(layout);

            var hasOauthPanel = Array.isArray(layout) && layout.some(function (panel) {
                return panel && panel.name === 'oauth';
            });

            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'inbound-email/record/edit',
                id: this.model.id || '',
                entityType: 'InboundEmail',
                message: 'layout:len=' + (Array.isArray(layout) ? layout.length : 'na') + ';oauth=' + (hasOauthPanel ? '1' : '0')
            }).catch(function () {});
        }
    });
});
