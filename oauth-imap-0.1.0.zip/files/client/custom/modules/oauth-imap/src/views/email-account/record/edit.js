define('modules/oauth-imap/views/email-account/record/edit', ['views/email-account/record/edit'], function (EditView) {
    'use strict';

    function appendOauthPanel(layout) {
        if (!Array.isArray(layout)) {
            return;
        }

        var hasPanel = layout.some(function (panel) {
            return panel && panel.name === 'oauth';
        });

        if (hasPanel) {
            return;
        }

        layout.push({
            name: 'oauth',
            label: 'OAuth',
            tabBreak: true,
            tabLabel: 'OAuth',
            rows: [
                [{ name: 'oauthProvider' }, { name: 'oauthEmail' }],
                [{ name: 'oauthImapEnabled' }, { name: 'oauthSmtpEnabled' }],
                [{ name: 'oauthClientId' }, { name: 'oauthClientSecret' }],
                [{ name: 'oauthTenantId' }, { name: 'oauthScopes', view: 'oauth-imap:views/oauth/effective-scopes' }]
            ]
        });
    }

    return EditView.extend({
        setup: function () {
            EditView.prototype.setup.call(this);

            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'email-account/record/edit',
                id: this.model.id || '',
                entityType: 'EmailAccount',
                message: 'setup'
            }).catch(function () {});

            if (!window.__oauthImapErrorHook) {
                window.__oauthImapErrorHook = true;
                window.addEventListener('error', function (event) {
                    Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                        view: 'window/error',
                        id: '',
                        entityType: 'EmailAccount',
                        message: 'window-error:' + (event && event.message ? event.message : 'unknown')
                    }).catch(function () {});
                });
                window.addEventListener('unhandledrejection', function (event) {
                    var reason = event && event.reason && event.reason.message ? event.reason.message : 'unknown';
                    Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                        view: 'window/rejection',
                        id: '',
                        entityType: 'EmailAccount',
                        message: 'window-rejection:' + reason
                    }).catch(function () {});
                });
            }

            this.listenTo(this.model, 'request', function () {
                Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                    view: 'email-account/record/edit',
                    id: this.model.id || '',
                    entityType: 'EmailAccount',
                    message: 'model-request'
                }).catch(function () {});
            }, this);

            this.listenTo(this.model, 'sync', function () {
                Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                    view: 'email-account/record/edit',
                    id: this.model.id || '',
                    entityType: 'EmailAccount',
                    message: 'model-sync'
                }).catch(function () {});
            }, this);

            this.listenTo(this.model, 'error', function () {
                Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                    view: 'email-account/record/edit',
                    id: this.model.id || '',
                    entityType: 'EmailAccount',
                    message: 'model-error'
                }).catch(function () {});
            }, this);
        },

        modifyDetailLayout: function (layout) {
            if (EditView.prototype.modifyDetailLayout) {
                EditView.prototype.modifyDetailLayout.call(this, layout);
            }

            appendOauthPanel(layout);

            var hasOauthPanel = Array.isArray(layout) && layout.some(function (panel) {
                return panel && panel.name === 'oauth';
            });

            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'email-account/record/edit',
                id: this.model.id || '',
                entityType: 'EmailAccount',
                message: 'layout:len=' + (Array.isArray(layout) ? layout.length : 'na') + ';oauth=' + (hasOauthPanel ? '1' : '0')
            }).catch(function () {});
        }
    });
});
