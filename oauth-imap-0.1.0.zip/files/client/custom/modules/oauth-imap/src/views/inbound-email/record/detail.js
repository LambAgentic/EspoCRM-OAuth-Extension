define('modules/oauth-imap/views/inbound-email/record/detail', ['views/inbound-email/record/detail'], function (DetailView) {
    'use strict';

    function appendOauthPanel(layout) {
        if (!Array.isArray(layout)) {
            return;
        }

        var hasPanel = layout.some(function (panel) {
            return panel && panel.name === 'oauth';
        });

        if (hasPanel) {
            return;
        }

        layout.push({
            name: 'oauth',
            label: 'OAuth IMAP',
            rows: [
                [{ name: 'oauthProvider' }, { name: 'oauthEmail' }],
                [{ name: 'oauthStatus' }, { name: 'oauthExpiresAt' }],
                [{ name: 'oauthScopes' }, { name: 'oauthLastError' }]
            ]
        });
    }

    return DetailView.extend({
        setup: function () {
            DetailView.prototype.setup.call(this);

            this.addButton({
                name: 'oauthConnect',
                label: 'Connect OAuth',
                style: 'default',
                onClick: this.onConnectClick.bind(this)
            });

            this.addButton({
                name: 'oauthDisconnect',
                label: 'Disconnect OAuth',
                style: 'danger',
                onClick: this.onDisconnectClick.bind(this)
            });

            this.addButton({
                name: 'oauthTestImap',
                label: 'Test IMAP',
                style: 'primary',
                onClick: this.onTestImapClick.bind(this)
            });

            this.listenTo(this.model, 'change:oauthStatus', this.updateOauthButtons, this);
            this.updateOauthButtons();
        },

        modifyDetailLayout: function (layout) {
            if (DetailView.prototype.modifyDetailLayout) {
                DetailView.prototype.modifyDetailLayout.call(this, layout);
            }

            appendOauthPanel(layout);

            var hasOauthPanel = Array.isArray(layout) && layout.some(function (panel) {
                return panel && panel.name === 'oauth';
            });

            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'inbound-email/record/detail',
                id: this.model.id || '',
                entityType: 'InboundEmail',
                message: 'layout:len=' + (Array.isArray(layout) ? layout.length : 'na') + ';oauth=' + (hasOauthPanel ? '1' : '0')
            }).catch(function () {});
        },

        updateOauthButtons: function () {
            var status = this.model.get('oauthStatus');

            this.toggleActionItem('oauthConnect', true);
            this.toggleActionItem('oauthDisconnect', status === 'connected');
            this.toggleActionItem('oauthTestImap', status === 'connected');
        },

        toggleActionItem: function (name, visible) {
            if (visible) {
                this.showActionItem(name);
            } else {
                this.hideActionItem(name);
            }
        },

        onConnectClick: function () {
            var accountId = this.model.id;
            var provider = this.model.get('oauthProvider');
            var payload = { accountId: accountId, usePkce: true, entityType: 'InboundEmail' };
            var self = this;

            if (!provider) {
                Espo.Ui.error(this.translate('selectValue', 'messages', 'Global') || 'Select OAuth Provider and save first.');
                return;
            }

            Espo.Ui.notify(this.translate('pleaseWait', 'messages'));

            Espo.Ajax.postRequest('OAuthImap/action/generateAuthUrl', payload)
                .then(function (response) {
                    if (response && response.authUrl) {
                        window.open(response.authUrl, '_blank');
                        Espo.Ui.success(self.translate('done', 'messages'));
                        return;
                    }

                    Espo.Ui.error(self.translate('Error'));
                })
                .catch(function (xhr) {
                    self.handleError(xhr);
                });
        },

        onDisconnectClick: function () {
            var accountId = this.model.id;
            var payload = { accountId: accountId, entityType: 'InboundEmail' };
            var self = this;

            Espo.Ui.notify(this.translate('pleaseWait', 'messages'));

            Espo.Ajax.postRequest('OAuthImap/action/disconnect', payload)
                .then(function () {
                    Espo.Ui.success(self.translate('done', 'messages'));
                    self.model.fetch();
                })
                .catch(function (xhr) {
                    self.handleError(xhr);
                });
        },

        onTestImapClick: function () {
            var accountId = this.model.id;
            var payload = { accountId: accountId, entityType: 'InboundEmail' };
            var self = this;

            Espo.Ui.notify(this.translate('pleaseWait', 'messages'));

            Espo.Ajax.postRequest('OAuthImap/action/testImap', payload)
                .then(function (response) {
                    if (response && response.success) {
                        Espo.Ui.success(self.translate('connectionIsOk', 'messages', 'InboundEmail'));
                        return;
                    }

                    var message = (response && response.message) ? response.message : self.translate('Error');
                    Espo.Ui.error(message, true);
                })
                .catch(function (xhr) {
                    self.handleError(xhr);
                });
        },

        handleError: function (xhr) {
            var statusReason = xhr.getResponseHeader('X-Status-Reason') || '';
            statusReason = statusReason.replace(/ $/, '');
            statusReason = statusReason.replace(/,$/, '');

            var msg = this.translate('Error');

            if (parseInt(xhr.status) !== 200) {
                msg += ' ' + xhr.status;
            }

            if (statusReason) {
                msg += ': ' + statusReason;
            }

            Espo.Ui.error(msg, true);

            xhr.errorIsHandled = true;
        }
    });
});
