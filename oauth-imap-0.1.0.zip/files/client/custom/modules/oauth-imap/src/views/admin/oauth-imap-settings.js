define('oauth-imap:views/admin/oauth-imap-settings', ['views/settings/record/edit'], function (SettingsEditView) {
    'use strict';

    return SettingsEditView.extend({
        detailLayout: [
            {
                tabBreak: true,
                tabLabel: 'OAuth IMAP',
                rows: [
                    [
                        { name: 'oauthImapRedirectUri' },
                        false
                    ],
                    [
                        { name: 'oauthImapGoogleClientId' },
                        { name: 'oauthImapGoogleClientSecret' }
                    ],
                    [
                        { name: 'oauthImapGoogleScopes' },
                        false
                    ],
                    [
                        { name: 'oauthImapMicrosoftClientId' },
                        { name: 'oauthImapMicrosoftClientSecret' }
                    ],
                    [
                        { name: 'oauthImapMicrosoftTenantId' },
                        { name: 'oauthImapMicrosoftScopes' }
                    ]
                ]
            }
        ],

        setup: function () {
            SettingsEditView.prototype.setup.call(this);
        }
    });
});
