define('modules/oauth-imap/views/oauth/panel-actions', ['views/fields/base'], function (Field) {
    'use strict';

    function getEntityType(model) {
        return model && (model.entityType || model.name || '') || '';
    }

    return Field.extend({
        isEmpty: function () {
            return false;
        },

        getValueForDisplay: function () {
            return '';
        },

        renderActions: function () {
            if (!this.$el) {
                return;
            }
            this.$el.html([
                '<div class="oauth-actions-panel">',
                '  <button type="button" class="btn btn-default btn-sm action-connect">Connect OAuth</button>',
                '  <button type="button" class="btn btn-danger btn-sm action-disconnect">Disconnect OAuth</button>',
                '</div>'
            ].join(''));
        },

        render: function () {
            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'oauth/panel-actions',
                id: this.model.id || '',
                entityType: getEntityType(this.model),
                message: 'render'
            }).catch(function () {});
            this.renderActions();
            return this;
        },

        events: {
            'click .action-connect': 'onConnectClick',
            'click .action-disconnect': 'onDisconnectClick'
        },

        setup: function () {
            Field.prototype.setup.call(this);
            this.listenTo(this.model, 'change:oauthStatus', this.updateButtons, this);
            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'oauth/panel-actions',
                id: this.model.id || '',
                entityType: getEntityType(this.model),
                message: 'setup'
            }).catch(function () {});
        },

        afterRender: function () {
            this.renderActions();
            this.updateButtons();
            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'oauth/panel-actions',
                id: this.model.id || '',
                entityType: getEntityType(this.model),
                message: 'afterRender'
            }).catch(function () {});
        },

        updateButtons: function () {
            var status = this.model.get('oauthStatus');
            if (!this.$el) {
                return;
            }
            this.$el.find('.action-connect').prop('disabled', false);
            this.$el.find('.action-disconnect').prop('disabled', status !== 'connected');
        },

        onConnectClick: function () {
            var accountId = this.model.id;
            var provider = this.model.get('oauthProvider');
            var payload = { accountId: accountId, usePkce: true, entityType: getEntityType(this.model) };
            var self = this;

            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'oauth/panel-actions',
                id: accountId || '',
                entityType: getEntityType(this.model),
                message: 'connect-click'
            }).catch(function () {});

            if (!provider) {
                Espo.Ui.error(this.translate('selectValue', 'messages', 'Global') || 'Select OAuth Provider and save first.');
                return;
            }

            Espo.Ui.notify(this.translate('pleaseWait', 'messages'));

            Espo.Ajax.postRequest('OAuthImap/action/generateAuthUrl', payload)
                .then(function (response) {
                    if (response && response.authUrl) {
                        window.open(response.authUrl, '_blank');
                        Espo.Ui.success(self.translate('done', 'messages'));
                        return;
                    }

                    Espo.Ui.error(self.translate('Error'));
                })
                .catch(function (xhr) {
                    self.handleError(xhr);
                });
        },

        onDisconnectClick: function () {
            var accountId = this.model.id;
            var payload = { accountId: accountId, entityType: getEntityType(this.model) };
            var self = this;

            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'oauth/panel-actions',
                id: accountId || '',
                entityType: getEntityType(this.model),
                message: 'disconnect-click'
            }).catch(function () {});

            Espo.Ui.notify(this.translate('pleaseWait', 'messages'));

            Espo.Ajax.postRequest('OAuthImap/action/disconnect', payload)
                .then(function () {
                    Espo.Ui.success(self.translate('done', 'messages'));
                    self.model.fetch();
                })
                .catch(function (xhr) {
                    self.handleError(xhr);
                });
        },

        handleError: function (xhr) {
            var statusReason = xhr.getResponseHeader('X-Status-Reason') || '';
            statusReason = statusReason.replace(/ $/, '');
            statusReason = statusReason.replace(/,$/, '');

            var msg = this.translate('Error');

            if (parseInt(xhr.status) !== 200) {
                msg += ' ' + xhr.status;
            }

            if (statusReason) {
                msg += ': ' + statusReason;
            }

            Espo.Ui.error(msg, true);
            xhr.errorIsHandled = true;
        }
    });
});
