define('modules/oauth-imap/views/email-account/record/detail', ['views/email-account/record/detail'], function (DetailView) {
    'use strict';

    function logDebug(message, data) {
        Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
            view: 'email-account/record/detail',
            id: (data && data.id) || '',
            entityType: 'EmailAccount',
            message: message
        }).catch(function () {});
    }

    function appendOauthPanel(layout, isEdit) {
        if (!Array.isArray(layout)) {
            return;
        }

        var hasPanel = layout.some(function (panel) {
            return panel && panel.name === 'oauth';
        });

        if (hasPanel) {
            return;
        }

        var rows = [
            [{ name: 'oauthProvider' }, { name: 'oauthEmail' }],
            [{ name: 'oauthImapEnabled' }, { name: 'oauthSmtpEnabled' }]
        ];

        if (isEdit) {
            rows.push([{ name: 'oauthClientId' }, { name: 'oauthClientSecret' }]);
            rows.push([{ name: 'oauthTenantId' }, { name: 'oauthScopes', view: 'oauth-imap:views/oauth/effective-scopes' }]);
        } else {
            rows.push([{ name: 'oauthStatus' }, { name: 'oauthExpiresAt' }]);
            rows.push([{ name: 'oauthScopes', view: 'oauth-imap:views/oauth/effective-scopes' }, { name: 'oauthLastError' }]);
            rows.push([{ name: 'oauthActions', view: 'oauth-imap:views/oauth/panel-actions' }, false]);
        }

        layout.push({
            name: 'oauth',
            label: 'OAuth',
            tabBreak: true,
            tabLabel: 'OAuth',
            rows: rows
        });
    }

    return DetailView.extend({
        setup: function () {
            DetailView.prototype.setup.call(this);

            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'email-account/record/detail',
                id: this.model.id || '',
                entityType: 'EmailAccount',
                message: 'setup'
            }).catch(function () {});

            if (!window.__oauthImapErrorHook) {
                window.__oauthImapErrorHook = true;
                window.addEventListener('error', function (event) {
                    Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                        view: 'window/error',
                        id: '',
                        entityType: 'EmailAccount',
                        message: 'window-error:' + (event && event.message ? event.message : 'unknown')
                    }).catch(function () {});
                });
                window.addEventListener('unhandledrejection', function (event) {
                    var reason = event && event.reason && event.reason.message ? event.reason.message : 'unknown';
                    Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                        view: 'window/rejection',
                        id: '',
                        entityType: 'EmailAccount',
                        message: 'window-rejection:' + reason
                    }).catch(function () {});
                });
            }

            this.listenTo(this.model, 'change:oauthStatus', this.updateOauthButtons, this);
            this.listenTo(this.model, 'change:oauthProvider', this.updateOauthButtons, this);
            this.updateOauthButtons();
        },

        modifyDetailLayout: function (layout) {
            if (DetailView.prototype.modifyDetailLayout) {
                DetailView.prototype.modifyDetailLayout.call(this, layout);
            }

            appendOauthPanel(layout, false);

            var hasOauthPanel = Array.isArray(layout) && layout.some(function (panel) {
                return panel && panel.name === 'oauth';
            });

            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'email-account/record/detail',
                id: this.model.id || '',
                entityType: 'EmailAccount',
                message: 'layout:len=' + (Array.isArray(layout) ? layout.length : 'na') + ';oauth=' + (hasOauthPanel ? '1' : '0')
            }).catch(function () {});
        },

        render: function () {
            logDebug('render:start', { id: this.model.id || '' });
            try {
                var res = DetailView.prototype.render.call(this);
                logDebug('render:ok', { id: this.model.id || '' });
                return res;
            } catch (e) {
                logDebug('render:error:' + (e && e.message ? e.message : 'unknown'), { id: this.model.id || '' });
                throw e;
            }
        },

        afterRender: function () {
            if (DetailView.prototype.afterRender) {
                DetailView.prototype.afterRender.call(this);
            }
            Espo.Ajax.getRequest('OAuthImap/action/debugClientPing', {
                view: 'email-account/record/detail',
                id: this.model.id || '',
                entityType: 'EmailAccount',
                message: 'afterRender'
            }).catch(function () {});
        },

        updateOauthButtons: function () {},

        handleError: function (xhr) {
            var statusReason = xhr.getResponseHeader('X-Status-Reason') || '';
            statusReason = statusReason.replace(/ $/, '');
            statusReason = statusReason.replace(/,$/, '');

            var msg = this.translate('Error');

            if (parseInt(xhr.status) !== 200) {
                msg += ' ' + xhr.status;
            }

            if (statusReason) {
                msg += ': ' + statusReason;
            }

            Espo.Ui.error(msg, true);

            xhr.errorIsHandled = true;
        }
    });
});
