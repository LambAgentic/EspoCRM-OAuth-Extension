define('oauth-imap:views/oauth/effective-scopes', ['views/fields/text'], function (TextField) {
    'use strict';

    return TextField.extend({
        readOnly: true,

        setup: function () {
            TextField.prototype.setup.call(this);
            this.listenTo(this.model, 'change:oauthProvider change:oauthScopes', this.reRender, this);
            this._effectiveScopesPromise = null;
            this._effectiveScopes = null;
        },

        getValueForDisplay: function () {
            var self = this;

            if (!this._effectiveScopesPromise) {
                this._effectiveScopesPromise = Espo.Ajax.getRequest('OAuthImap/action/effectiveScopes', {
                    id: this.model.id || '',
                    entityType: this.model.entityType || 'EmailAccount'
                }).then(function (response) {
                    self._effectiveScopes = response && response.scopesString ? response.scopesString : '';
                    return self._effectiveScopes;
                }).catch(function () {
                    self._effectiveScopes = '';
                    return self._effectiveScopes;
                });
            }

            if (this._effectiveScopes === null) {
                this._effectiveScopesPromise.then(function () {
                    self.reRender();
                });
                return '';
            }

            return this._effectiveScopes || '';
        }
    });
});
