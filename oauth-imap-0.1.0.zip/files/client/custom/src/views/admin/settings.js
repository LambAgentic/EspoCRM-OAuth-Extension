import SettingsEditRecordView from 'views/settings/record/edit';

class SettingsAdminRecordView extends SettingsEditRecordView {

    layoutName = 'settings'

    saveAndContinueEditingAction = false

    dynamicLogicDefs = {
        fields: {
            phoneNumberPreferredCountryList: {
                visible: {
                    conditionGroup: [
                        {
                            attribute: 'phoneNumberInternational',
                            type: 'isTrue'
                        }
                    ]
                }
            },
            phoneNumberExtensions: {
                visible: {
                    conditionGroup: [
                        {
                            attribute: 'phoneNumberInternational',
                            type: 'isTrue'
                        }
                    ]
                }
            }
        }
    }

    setup() {
        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/00567651-5b99-456f-a37d-58520f02ad45', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({location: 'client/custom/src/views/admin/settings.js:34', message: 'Admin settings setup start', data: {layoutName: this.layoutName}, timestamp: Date.now(), sessionId: 'debug-session', runId: 'run1', hypothesisId: 'S1'})}).catch(() => {});
        // #endregion agent log

        super.setup();

        const metadata = this.getMetadata();
        const fieldDef = metadata.get(['entityDefs', 'Settings', 'fields', 'oauthImapRedirectUri']) || null;
        const settingDef = metadata.get(['app', 'settingDefs', 'oauthImapRedirectUri']) || null;
        const layout = metadata.get(['layouts', 'Settings', 'settings']) || null;
        const layoutHasField = Array.isArray(layout) && layout.some(section => {
            const rows = section && section.rows ? section.rows : [];
            return rows.some(row => Array.isArray(row) && row.some(cell => cell && cell.name === 'oauthImapRedirectUri'));
        });

        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/00567651-5b99-456f-a37d-58520f02ad45', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({location: 'client/custom/src/views/admin/settings.js:50', message: 'OAuth IMAP settings metadata', data: {hasFieldDef: !!fieldDef, hasSettingDef: !!settingDef, layoutHasField: layoutHasField, layoutType: Array.isArray(layout) ? 'array' : typeof layout}, timestamp: Date.now(), sessionId: 'debug-session', runId: 'run1', hypothesisId: 'S2'})}).catch(() => {});
        // #endregion agent log

        if (this.getHelper().getAppParam('isRestrictedMode') && !this.getUser().isSuperAdmin()) {
            this.hideField('cronDisabled');
            this.hideField('maintenanceMode');
            this.setFieldReadOnly('useWebSocket');
            this.setFieldReadOnly('siteUrl');
        }

        // #region agent log
        fetch('http://127.0.0.1:7244/ingest/00567651-5b99-456f-a37d-58520f02ad45', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({location: 'client/custom/src/views/admin/settings.js:67', message: 'Admin settings setup complete', data: {restrictedMode: !!this.getHelper().getAppParam('isRestrictedMode')}, timestamp: Date.now(), sessionId: 'debug-session', runId: 'run1', hypothesisId: 'S3'})}).catch(() => {});
        // #endregion agent log
    }
}

export default SettingsAdminRecordView;
