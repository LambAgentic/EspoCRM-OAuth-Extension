<?php

namespace Espo\Modules\OAuthImap\Smtp;

use Espo\Core\Mail\Smtp\Handler;
use Espo\Core\Mail\SmtpParams;
use Espo\Entities\EmailAccount;
use Espo\Entities\InboundEmail;
use Espo\ORM\EntityManager;
use Espo\Modules\OAuthImap\Imap\Xoauth2AuthStringBuilder;
use Espo\Modules\OAuthImap\Services\OAuthImapService;

class Xoauth2SmtpHandler implements Handler
{
    public function __construct(
        private EntityManager $entityManager,
        private OAuthImapService $oauthImapService,
        private Xoauth2AuthStringBuilder $authStringBuilder
    ) {}

    public function handle(SmtpParams $params, ?string $id): SmtpParams
    {
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'SMTP1',
                'location' => 'Xoauth2SmtpHandler.php:26',
                'message' => 'SMTP handler invoked',
                'data' => [
                    'hasId' => (bool) $id,
                    'hasServer' => (bool) $params->getServer(),
                    'hasUsername' => (bool) $params->getUsername(),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        if (!$id) {
            return $params;
        }

        $account = $this->entityManager->getEntityById(EmailAccount::ENTITY_TYPE, $id)
            ?? $this->entityManager->getEntityById(InboundEmail::ENTITY_TYPE, $id);

        if (!$account) {
            return $params;
        }

        $email = (string) ($account->get('oauthEmail')
            ?: $account->get('smtpUsername')
            ?: $account->get('emailAddress')
            ?: $params->getUsername());

        if ($email === '') {
            return $params;
        }

        $accessToken = $this->oauthImapService->getValidAccessToken($account);
        $authString = $this->authStringBuilder->build($email, $accessToken);

        $connectionOptions = $params->getConnectionOptions() ?? [];
        $connectionOptions['authString'] = $authString;

        $updated = $params
            ->withConnectionOptions($connectionOptions)
            ->withAuth(true);

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'SMTP2',
                'location' => 'Xoauth2SmtpHandler.php:71',
                'message' => 'SMTP handler configured authString',
                'data' => [
                    'entityType' => $account->getEntityType(),
                    'emailPresent' => $email !== '',
                    'connectionOptionsKeys' => array_keys($connectionOptions),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        return $updated;
    }
}
