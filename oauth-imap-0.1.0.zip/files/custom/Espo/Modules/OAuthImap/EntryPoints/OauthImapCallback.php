<?php

namespace Espo\Modules\OAuthImap\EntryPoints;

use Espo\Core\Api\Request;
use Espo\Core\Api\Response;
use Espo\Core\EntryPoint\EntryPoint;
use Espo\Core\Exceptions\BadRequest;
use Espo\Modules\OAuthImap\Services\OAuthImapService;

class OauthImapCallback implements EntryPoint
{
    public static bool $noAuth = true;

    public function __construct(private OAuthImapService $service)
    {}

    public function run(Request $request, Response $response): void
    {
        $state = $request->getQueryParam('state');
        $code = $request->getQueryParam('code');
        $error = $request->getQueryParam('error');

        if ($error) {
            $this->writeHtml($response, 'OAuth authorization failed. You can close this window.');
            return;
        }

        if (!$state || !$code) {
            throw new BadRequest('Missing callback parameters.');
        }

        $this->service->handleCallback($state, $code);

        $this->writeHtml($response, 'OAuth connection successful. You can close this window.');
    }

    private function writeHtml(Response $response, string $message): void
    {
        $response
            ->setHeader('Content-Type', 'text/html; charset=utf-8')
            ->writeBody('<html><body>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</body></html>');
    }
}
