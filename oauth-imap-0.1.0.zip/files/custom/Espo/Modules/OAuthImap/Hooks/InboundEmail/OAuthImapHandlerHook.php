<?php

namespace Espo\Modules\OAuthImap\Hooks\InboundEmail;

use Espo\Core\Record\Hook\SaveHook;
use Espo\Entities\InboundEmail;
use Espo\ORM\Entity;
use Espo\Modules\OAuthImap\Imap\Xoauth2ImapHandler;
use Espo\Modules\OAuthImap\Smtp\Xoauth2SmtpHandler;

class OAuthImapHandlerHook implements SaveHook
{
    public function process(Entity $entity): void
    {
        if (!$entity instanceof InboundEmail) {
            return;
        }

        $provider = $entity->get('oauthProvider');
        $imapEnabledRaw = $entity->get('oauthImapEnabled');
        $smtpEnabledRaw = $entity->get('oauthSmtpEnabled');
        $imapEnabled = $imapEnabledRaw === null ? true : (bool) $imapEnabledRaw;
        $smtpEnabled = $smtpEnabledRaw === null ? true : (bool) $smtpEnabledRaw;

        if ($imapEnabled || $smtpEnabled) {
            if ($imapEnabled) {
                $entity->set('imapHandler', Xoauth2ImapHandler::class);
            } else {
                $entity->set('imapHandler', null);
            }

            if ($smtpEnabled) {
                $entity->set('smtpHandler', Xoauth2SmtpHandler::class);
            } else {
                $entity->set('smtpHandler', null);
            }

            $oauthEmail = $entity->get('oauthEmail');
            if ($oauthEmail) {
                if ($imapEnabled) {
                    $entity->set('username', $oauthEmail);
                }
                if ($smtpEnabled) {
                    $entity->set('smtpUsername', $oauthEmail);
                }
            }

            if ($imapEnabled) {
                $entity->set('password', null);
            }
            if ($smtpEnabled) {
                $entity->set('smtpPassword', null);
            }

            if (!$provider) {
                $entity->set('oauthStatus', 'error');
                $entity->set('oauthLastError', 'OAuth provider is required when OAuth IMAP/SMTP is enabled.');
            }

            return;
        }

        $entity->set('imapHandler', null);
        $entity->set('smtpHandler', null);
    }
}
