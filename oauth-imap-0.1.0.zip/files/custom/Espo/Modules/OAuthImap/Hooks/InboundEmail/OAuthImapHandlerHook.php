<?php

namespace Espo\Modules\OAuthImap\Hooks\InboundEmail;

use Espo\Core\Record\Hook\SaveHook;
use Espo\Entities\InboundEmail;
use Espo\ORM\Entity;
use Espo\Modules\OAuthImap\Imap\Xoauth2ImapHandler;
use Espo\Modules\OAuthImap\Smtp\Xoauth2SmtpHandler;

class OAuthImapHandlerHook implements SaveHook
{
    public function process(Entity $entity): void
    {
        if (!$entity instanceof InboundEmail) {
            return;
        }

        $provider = $entity->get('oauthProvider');
        if ($provider) {
            $entity->set('imapHandler', Xoauth2ImapHandler::class);
            $entity->set('smtpHandler', Xoauth2SmtpHandler::class);

            $oauthEmail = $entity->get('oauthEmail');
            if ($oauthEmail) {
                $entity->set('username', $oauthEmail);
                $entity->set('smtpUsername', $oauthEmail);
            }

            $entity->set('password', null);
            $entity->set('smtpPassword', null);

            return;
        }

        $entity->set('imapHandler', null);
        $entity->set('smtpHandler', null);
    }
}
