<?php

namespace Espo\Modules\OAuthImap\Integration\Stub;

use Espo\Modules\OAuthImap\Integration\AuthGuardInterface;

class AllowAllAuthGuard implements AuthGuardInterface
{
    public function assertAuthenticated(): void
    {
    }

    public function assertAdmin(): void
    {
    }
}
