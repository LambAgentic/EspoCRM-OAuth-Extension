<?php

namespace Espo\Modules\OAuthImap\Integration\Stub;

use Espo\Modules\OAuthImap\Integration\CredentialCryptoInterface;

class NullCredentialCrypto implements CredentialCryptoInterface
{
    public function encrypt(string $plaintext): string
    {
        return $plaintext;
    }

    public function decrypt(string $ciphertext): string
    {
        return $ciphertext;
    }
}
