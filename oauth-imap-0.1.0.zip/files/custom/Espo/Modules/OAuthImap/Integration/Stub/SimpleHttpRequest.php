<?php

namespace Espo\Modules\OAuthImap\Integration\Stub;

use Espo\Modules\OAuthImap\Integration\HttpRequestInterface;

class SimpleHttpRequest implements HttpRequestInterface
{
    private string $method;
    private array $query;
    private array $post;
    private array $headers;

    public function __construct(string $method, array $query = [], array $post = [], array $headers = [])
    {
        $this->method = strtoupper($method);
        $this->query = $query;
        $this->post = $post;
        $this->headers = [];
        foreach ($headers as $name => $value) {
            $this->headers[strtolower($name)] = $value;
        }
    }

    public function getMethod(): string
    {
        return $this->method;
    }

    public function getQueryParam(string $name, ?string $default = null): ?string
    {
        return $this->query[$name] ?? $default;
    }

    public function getPostParam(string $name, ?string $default = null): ?string
    {
        return $this->post[$name] ?? $default;
    }

    public function getHeader(string $name, ?string $default = null): ?string
    {
        $key = strtolower($name);
        return $this->headers[$key] ?? $default;
    }
}
