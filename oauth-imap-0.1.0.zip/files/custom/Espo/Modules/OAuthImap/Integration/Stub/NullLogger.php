<?php

namespace Espo\Modules\OAuthImap\Integration\Stub;

use Espo\Modules\OAuthImap\Integration\LoggerInterface;

class NullLogger implements LoggerInterface
{
    public function info(string $message, array $context = []): void
    {
    }

    public function error(string $message, array $context = []): void
    {
    }
}
