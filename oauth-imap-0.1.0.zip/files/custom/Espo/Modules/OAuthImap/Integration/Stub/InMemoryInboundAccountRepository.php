<?php

namespace Espo\Modules\OAuthImap\Integration\Stub;

use Espo\Modules\OAuthImap\Integration\InboundAccountRepositoryInterface;
use Espo\Modules\OAuthImap\Models\InboundAccount;
use RuntimeException;

class InMemoryInboundAccountRepository implements InboundAccountRepositoryInterface
{
    /** @var array<string, InboundAccount> */
    private array $items = [];

    public function getById(string $id): InboundAccount
    {
        if (!isset($this->items[$id])) {
            throw new RuntimeException('Inbound account not found: ' . $id);
        }

        return $this->items[$id];
    }

    public function save(InboundAccount $account): void
    {
        $this->items[$account->getId()] = $account;
    }

    public function seed(InboundAccount $account): void
    {
        $this->items[$account->getId()] = $account;
    }
}
