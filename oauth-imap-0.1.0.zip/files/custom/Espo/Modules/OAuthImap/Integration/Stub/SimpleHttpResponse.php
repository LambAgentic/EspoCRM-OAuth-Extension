<?php

namespace Espo\Modules\OAuthImap\Integration\Stub;

use Espo\Modules\OAuthImap\Integration\HttpResponseInterface;

class SimpleHttpResponse implements HttpResponseInterface
{
    public array $lastJson = [];
    public int $lastJsonStatus = 200;
    public ?string $lastRedirect = null;
    public int $lastRedirectStatus = 302;

    public function json(array $payload, int $statusCode = 200): void
    {
        $this->lastJson = $payload;
        $this->lastJsonStatus = $statusCode;
    }

    public function redirect(string $url, int $statusCode = 302): void
    {
        $this->lastRedirect = $url;
        $this->lastRedirectStatus = $statusCode;
    }
}
