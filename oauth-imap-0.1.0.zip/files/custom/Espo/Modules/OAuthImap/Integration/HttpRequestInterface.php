<?php

namespace Espo\Modules\OAuthImap\Integration;

interface HttpRequestInterface
{
    public function getMethod(): string;

    public function getQueryParam(string $name, ?string $default = null): ?string;

    public function getPostParam(string $name, ?string $default = null): ?string;

    public function getHeader(string $name, ?string $default = null): ?string;
}
