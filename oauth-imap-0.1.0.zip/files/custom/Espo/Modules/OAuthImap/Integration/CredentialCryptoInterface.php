<?php

namespace Espo\Modules\OAuthImap\Integration;

interface CredentialCryptoInterface
{
    public function encrypt(string $plaintext): string;

    public function decrypt(string $ciphertext): string;
}
