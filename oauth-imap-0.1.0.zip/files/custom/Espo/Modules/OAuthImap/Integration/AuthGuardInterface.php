<?php

namespace Espo\Modules\OAuthImap\Integration;

interface AuthGuardInterface
{
    public function assertAuthenticated(): void;

    public function assertAdmin(): void;
}
