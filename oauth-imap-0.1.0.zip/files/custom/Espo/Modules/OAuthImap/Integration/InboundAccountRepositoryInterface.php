<?php

namespace Espo\Modules\OAuthImap\Integration;

use Espo\Modules\OAuthImap\Models\InboundAccount;

interface InboundAccountRepositoryInterface
{
    public function getById(string $id): InboundAccount;

    public function save(InboundAccount $account): void;
}
