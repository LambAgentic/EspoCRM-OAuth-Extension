<?php

namespace Espo\Modules\OAuthImap\Integration;

interface HttpResponseInterface
{
    public function json(array $payload, int $statusCode = 200): void;

    public function redirect(string $url, int $statusCode = 302): void;
}
