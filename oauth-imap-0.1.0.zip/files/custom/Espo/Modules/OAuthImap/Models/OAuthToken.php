<?php

namespace Espo\Modules\OAuthImap\Models;

use League\OAuth2\Client\Token\AccessTokenInterface;

class OAuthToken
{
    private string $accessToken;
    private ?string $refreshToken;
    private ?int $expiresAt;
    /** @var string[] */
    private array $scopes;

    /**
     * @param string[] $scopes
     */
    public function __construct(string $accessToken, ?string $refreshToken, ?int $expiresAt, array $scopes = [])
    {
        $this->accessToken = $accessToken;
        $this->refreshToken = $refreshToken;
        $this->expiresAt = $expiresAt;
        $this->scopes = $scopes;
    }

    public static function fromLeagueToken(AccessTokenInterface $token): self
    {
        $values = $token->getValues();
        $scopes = [];
        if (isset($values['scope'])) {
            $scopes = is_array($values['scope']) ? $values['scope'] : preg_split('/\s+/', trim((string) $values['scope']));
        }

        return new self(
            $token->getToken(),
            $token->getRefreshToken(),
            $token->getExpires(),
            $scopes ?? []
        );
    }

    public function getAccessToken(): string
    {
        return $this->accessToken;
    }

    public function getRefreshToken(): ?string
    {
        return $this->refreshToken;
    }

    public function getExpiresAt(): ?int
    {
        return $this->expiresAt;
    }

    /**
     * @return string[]
     */
    public function getScopes(): array
    {
        return $this->scopes;
    }
}
