<?php

namespace Espo\Modules\OAuthImap\Models;

class InboundAccount
{
    private string $id;
    private array $data = [];

    public function __construct(string $id, array $data = [])
    {
        $this->id = $id;
        $this->data = $data;
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function get(string $field, $default = null)
    {
        return $this->data[$field] ?? $default;
    }

    public function set(string $field, $value): void
    {
        $this->data[$field] = $value;
    }

    public function toArray(): array
    {
        return $this->data;
    }

    public static function fromArray(string $id, array $data): self
    {
        return new self($id, $data);
    }
}
