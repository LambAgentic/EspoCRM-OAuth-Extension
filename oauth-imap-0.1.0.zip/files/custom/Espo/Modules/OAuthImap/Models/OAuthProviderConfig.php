<?php

namespace Espo\Modules\OAuthImap\Models;

class OAuthProviderConfig
{
    private string $provider;
    private string $clientId;
    private string $clientSecret;
    private ?string $tenantId;
    private string $redirectUri;
    /** @var string[] */
    private array $scopes;

    /**
     * @param string[] $scopes
     */
    public function __construct(
        string $provider,
        string $clientId,
        string $clientSecret,
        string $redirectUri,
        array $scopes,
        ?string $tenantId = null
    ) {
        $this->provider = $provider;
        $this->clientId = $clientId;
        $this->clientSecret = $clientSecret;
        $this->redirectUri = $redirectUri;
        $this->scopes = $scopes;
        $this->tenantId = $tenantId;
    }

    public function getProvider(): string
    {
        return $this->provider;
    }

    public function getClientId(): string
    {
        return $this->clientId;
    }

    public function getClientSecret(): string
    {
        return $this->clientSecret;
    }

    public function getTenantId(): ?string
    {
        return $this->tenantId;
    }

    public function getRedirectUri(): string
    {
        return $this->redirectUri;
    }

    /**
     * @return string[]
     */
    public function getScopes(): array
    {
        return $this->scopes;
    }
}
