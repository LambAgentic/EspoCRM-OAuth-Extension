<?php

namespace Espo\Modules\OAuthImap\Controllers;

use Espo\Core\Api\Request;
use Espo\Core\Controllers\Record;
use Espo\Core\Exceptions\BadRequest;
use Espo\Core\Exceptions\Forbidden;
use Espo\Entities\EmailAccount;
use Espo\Entities\InboundEmail;
use Espo\ORM\Entity;
use Espo\Tools\Layout\LayoutProvider;
use Espo\Modules\OAuthImap\Services\OAuthImapService;

class OAuthImap extends Record
{
    protected function checkAccess(): bool
    {
        return true;
    }

    /**
     * @return array<string, string>
     * @throws BadRequest
     * @throws Forbidden
     */
    public function postActionGenerateAuthUrl(Request $request): array
    {
        $data = $request->getParsedBody();
        $accountId = $data->accountId ?? null;
        $usePkce = $data->usePkce ?? true;
        $entityType = $data->entityType ?? InboundEmail::ENTITY_TYPE;

        if (!$accountId) {
            throw new BadRequest('Missing accountId.');
        }

        $account = $this->getAccountOrFail((string) $entityType, (string) $accountId);
        $this->assertAccess($account);

        $result = $this->getOAuthImapService()->generateAuthUrl((string) $accountId, (bool) $usePkce, (string) $entityType);

        return [
            'authUrl' => $result['url'],
        ];
    }

    /**
     * @throws BadRequest
     * @throws Forbidden
     */
    public function postActionDisconnect(Request $request): bool
    {
        $data = $request->getParsedBody();
        $accountId = $data->accountId ?? null;
        $entityType = $data->entityType ?? InboundEmail::ENTITY_TYPE;

        if (!$accountId) {
            throw new BadRequest('Missing accountId.');
        }

        $account = $this->getAccountOrFail((string) $entityType, (string) $accountId);
        $this->assertAccess($account);

        $this->getOAuthImapService()->disconnect((string) $accountId, (string) $entityType);

        return true;
    }

    /**
     * @return array<string, mixed>
     * @throws BadRequest
     * @throws Forbidden
     */
    public function postActionTestImap(Request $request): array
    {
        $data = $request->getParsedBody();
        $accountId = $data->accountId ?? null;
        $entityType = $data->entityType ?? InboundEmail::ENTITY_TYPE;

        if (!$accountId) {
            throw new BadRequest('Missing accountId.');
        }

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H1',
                'location' => 'OAuthImap.php:90',
                'message' => 'Test IMAP request received',
                'data' => [
                    'accountId' => (string) $accountId,
                    'entityType' => (string) $entityType,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap TestImap] request entityType=' . (string) $entityType . ' accountId=' . (string) $accountId);

        $account = $this->getAccountOrFail((string) $entityType, (string) $accountId);
        $this->assertAccess($account);

        try {
            $result = $this->getOAuthImapService()->testImap((string) $accountId, (string) $entityType);

            // #region agent log
            @file_put_contents(
                'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
                json_encode([
                    'sessionId' => 'debug-session',
                    'runId' => 'run1',
                    'hypothesisId' => 'H4',
                    'location' => 'OAuthImap.php:112',
                    'message' => 'Test IMAP completed',
                    'data' => [
                        'success' => (bool) ($result['success'] ?? false),
                        'hasCapabilities' => !empty($result['capabilities'] ?? null),
                        'hasGreeting' => !empty($result['greeting'] ?? null),
                    ],
                    'timestamp' => (int) (microtime(true) * 1000),
                ]) . PHP_EOL,
                FILE_APPEND
            );
            // #endregion agent log

            return $result;
        } catch (\Throwable $e) {
            // #region agent log
            @file_put_contents(
                'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
                json_encode([
                    'sessionId' => 'debug-session',
                    'runId' => 'run1',
                    'hypothesisId' => 'H5',
                    'location' => 'OAuthImap.php:129',
                    'message' => 'Test IMAP failed',
                    'data' => [
                        'errorClass' => get_class($e),
                        'errorCode' => $e->getCode(),
                        'entityType' => (string) $entityType,
                    ],
                    'timestamp' => (int) (microtime(true) * 1000),
                ]) . PHP_EOL,
                FILE_APPEND
            );
            // #endregion agent log
            error_log('[OAuthImap TestImap] failed errorClass=' . get_class($e) . ' code=' . $e->getCode());
            throw $e;
        }
    }

    /**
     * @return array<string, mixed>
     */
    public function getActionDebugSettings(): array
    {
        $metadata = $this->getMetadata();
        $fieldDef = $metadata->get(['entityDefs', 'Settings', 'fields', 'oauthImapRedirectUri']);
        $settingDef = $metadata->get(['app', 'settingDefs', 'oauthImapRedirectUri']);
        $configDef = $metadata->get(['app', 'config', 'params', 'oauthImapRedirectUri']);
        $adminPanel = $metadata->get(['app', 'adminPanel', 'oauthImap', 'itemList']);
        $layout = $metadata->get(['layouts', 'Settings', 'settings']);

        $layoutHasField = false;
        $sectionCount = 0;

        if (is_array($layout)) {
            $sectionCount = count($layout);
            foreach ($layout as $section) {
                $rows = is_array($section) && array_key_exists('rows', $section) ? $section['rows'] : [];
                if (!is_array($rows)) {
                    continue;
                }
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    foreach ($row as $cell) {
                        if (is_array($cell) && ($cell['name'] ?? null) === 'oauthImapRedirectUri') {
                            $layoutHasField = true;
                            break 3;
                        }
                    }
                }
            }
        }

        $result = [
            'hasFieldDef' => (bool) $fieldDef,
            'hasSettingDef' => (bool) $settingDef,
            'hasConfigDef' => (bool) $configDef,
            'adminPanelItems' => is_array($adminPanel) ? count($adminPanel) : 0,
            'layoutHasField' => $layoutHasField,
            'layoutType' => gettype($layout),
            'layoutSectionCount' => $sectionCount,
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'S4',
                'location' => 'OAuthImap.php:101',
                'message' => 'Debug settings metadata',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugSettings] ' . json_encode($result));

        return $result;
    }

    /**
     * @return array<string, mixed>
     */
    public function getActionDebugInboundEmailLayout(): array
    {
        $metadata = $this->getMetadata();
        $fieldDefs = $metadata->get(['entityDefs', 'InboundEmail', 'fields']) ?? [];
        $layout = $metadata->get(['layouts', 'InboundEmail', 'detail']);

        $oauthFields = [
            'oauthProvider',
            'oauthEmail',
            'oauthStatus',
            'oauthExpiresAt',
            'oauthScopes',
            'oauthLastError',
        ];

        $hasOauthFields = [];
        foreach ($oauthFields as $field) {
            $hasOauthFields[$field] = is_array($fieldDefs) && array_key_exists($field, $fieldDefs);
        }

        $layoutHasOAuthPanel = false;
        $layoutHasOauthField = false;
        $sectionCount = 0;

        if (is_array($layout)) {
            $sectionCount = count($layout);
            foreach ($layout as $section) {
                if (is_array($section) && ($section['name'] ?? null) === 'oauth') {
                    $layoutHasOAuthPanel = true;
                }
                $rows = is_array($section) && array_key_exists('rows', $section) ? $section['rows'] : [];
                if (!is_array($rows)) {
                    continue;
                }
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    foreach ($row as $cell) {
                        if (is_array($cell) && in_array(($cell['name'] ?? ''), $oauthFields, true)) {
                            $layoutHasOauthField = true;
                            break 3;
                        }
                    }
                }
            }
        }

        $result = [
            'layoutType' => gettype($layout),
            'layoutSectionCount' => $sectionCount,
            'layoutHasOAuthPanel' => $layoutHasOAuthPanel,
            'layoutHasOauthField' => $layoutHasOauthField,
            'fieldDefsPresent' => $hasOauthFields,
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'I1',
                'location' => 'OAuthImap.php:151',
                'message' => 'Debug InboundEmail layout metadata',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugInboundEmailLayout] ' . json_encode($result));

        return $result;
    }

    /**
     * @param Request $request
     * @return array<string, mixed>
     */
    public function getActionDebugInboundEmailRecord(Request $request): array
    {
        $accountId = (string) ($request->getQueryParam('id') ?? '');
        if ($accountId === '') {
            throw new BadRequest('Missing id.');
        }

        $account = $this->getAccountOrFail(InboundEmail::ENTITY_TYPE, $accountId);
        $this->assertAccess($account);

        $result = [
            'id' => $account->getId(),
            'oauthProvider' => $account->get('oauthProvider'),
            'oauthStatus' => $account->get('oauthStatus'),
            'oauthEmail' => $account->get('oauthEmail'),
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'I2',
                'location' => 'OAuthImap.php:207',
                'message' => 'Debug InboundEmail record',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugInboundEmailRecord] ' . json_encode($result));

        return $result;
    }

    /**
     * @return array<string, mixed>
     */
    public function getActionDebugInboundEmailLayoutPaths(): array
    {
        $base = dirname(__DIR__, 5);
        $candidates = [
            $base . '/custom/Espo/Resources/layouts/InboundEmail/detail.json',
            $base . '/custom/Espo/Resources/layouts/InboundEmail/edit.json',
            $base . '/custom/Espo/Custom/Resources/layouts/InboundEmail/detail.json',
            $base . '/custom/Espo/Custom/Resources/layouts/InboundEmail/edit.json',
            $base . '/custom/Espo/Modules/OAuthImap/Resources/metadata/layouts/InboundEmail/detail.json',
            $base . '/custom/Espo/Modules/OAuthImap/Resources/metadata/layouts/InboundEmail/edit.json',
            $base . '/custom/Espo/Modules/OAuthImap/Resources/layouts/InboundEmail/detail.json',
            $base . '/custom/Espo/Modules/OAuthImap/Resources/layouts/InboundEmail/edit.json',
        ];

        $results = [];
        foreach ($candidates as $path) {
            $results[] = [
                'path' => $path,
                'exists' => file_exists($path),
            ];
        }

        $result = [
            'base' => $base,
            'candidates' => $results,
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'I3',
                'location' => 'OAuthImap.php:259',
                'message' => 'Debug InboundEmail layout paths',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugInboundEmailLayoutPaths] ' . json_encode($result));

        return $result;
    }

    /**
     * @return array<string, mixed>
     */
    public function getActionDebugEmailAccountLayout(): array
    {
        $metadata = $this->getMetadata();
        $fieldDefs = $metadata->get(['entityDefs', 'EmailAccount', 'fields']) ?? [];
        $layout = $metadata->get(['layouts', 'EmailAccount', 'detail']);

        $oauthFields = [
            'oauthProvider',
            'oauthEmail',
            'oauthStatus',
            'oauthExpiresAt',
            'oauthScopes',
            'oauthLastError',
        ];

        $hasOauthFields = [];
        foreach ($oauthFields as $field) {
            $hasOauthFields[$field] = is_array($fieldDefs) && array_key_exists($field, $fieldDefs);
        }

        $layoutHasOAuthPanel = false;
        $layoutHasOauthField = false;
        $sectionCount = 0;

        if (is_array($layout)) {
            $sectionCount = count($layout);
            foreach ($layout as $section) {
                if (is_array($section) && ($section['name'] ?? null) === 'oauth') {
                    $layoutHasOAuthPanel = true;
                }
                $rows = is_array($section) && array_key_exists('rows', $section) ? $section['rows'] : [];
                if (!is_array($rows)) {
                    continue;
                }
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    foreach ($row as $cell) {
                        if (is_array($cell) && in_array(($cell['name'] ?? ''), $oauthFields, true)) {
                            $layoutHasOauthField = true;
                            break 3;
                        }
                    }
                }
            }
        }

        $result = [
            'layoutType' => gettype($layout),
            'layoutSectionCount' => $sectionCount,
            'layoutHasOAuthPanel' => $layoutHasOAuthPanel,
            'layoutHasOauthField' => $layoutHasOauthField,
            'fieldDefsPresent' => $hasOauthFields,
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'E2',
                'location' => 'OAuthImap.php:362',
                'message' => 'Debug EmailAccount layout metadata',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugEmailAccountLayout] ' . json_encode($result));

        return $result;
    }

    /**
     * @param Request $request
     * @return array<string, mixed>
     */
    public function getActionDebugEmailAccountRecord(Request $request): array
    {
        $accountId = (string) ($request->getQueryParam('id') ?? '');
        if ($accountId === '') {
            throw new BadRequest('Missing id.');
        }

        $account = $this->getAccountOrFail(EmailAccount::ENTITY_TYPE, $accountId);
        $this->assertAccess($account);

        $result = [
            'id' => $account->getId(),
            'oauthProvider' => $account->get('oauthProvider'),
            'oauthStatus' => $account->get('oauthStatus'),
            'oauthEmail' => $account->get('oauthEmail'),
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'E3',
                'location' => 'OAuthImap.php:416',
                'message' => 'Debug EmailAccount record',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugEmailAccountRecord] ' . json_encode($result));

        return $result;
    }

    /**
     * @return array<string, mixed>
     */
    public function getActionDebugEmailAccountLayoutPaths(): array
    {
        $base = dirname(__DIR__, 5);
        $candidates = [
            $base . '/custom/Espo/Custom/Resources/layouts/EmailAccount/detail.json',
            $base . '/custom/Espo/Custom/Resources/layouts/EmailAccount/edit.json',
            $base . '/custom/Espo/Resources/layouts/EmailAccount/detail.json',
            $base . '/custom/Espo/Resources/layouts/EmailAccount/edit.json',
            $base . '/custom/Espo/Modules/OAuthImap/Resources/metadata/layouts/EmailAccount/detail.json',
            $base . '/custom/Espo/Modules/OAuthImap/Resources/metadata/layouts/EmailAccount/edit.json',
            $base . '/custom/Espo/Modules/OAuthImap/Resources/layouts/EmailAccount/detail.json',
            $base . '/custom/Espo/Modules/OAuthImap/Resources/layouts/EmailAccount/edit.json',
        ];

        $results = [];
        foreach ($candidates as $path) {
            $results[] = [
                'path' => $path,
                'exists' => file_exists($path),
            ];
        }

        $result = [
            'base' => $base,
            'candidates' => $results,
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'E4',
                'location' => 'OAuthImap.php:467',
                'message' => 'Debug EmailAccount layout paths',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugEmailAccountLayoutPaths] ' . json_encode($result));

        return $result;
    }

    /**
     * @param Request $request
     * @return array<string, mixed>
     */
    public function getActionDebugLayoutProvider(Request $request): array
    {
        $scope = (string) ($request->getQueryParam('scope') ?? '');
        $name = (string) ($request->getQueryParam('name') ?? '');
        if ($scope === '' || $name === '') {
            throw new BadRequest('Missing scope or name.');
        }

        /** @var LayoutProvider $layoutProvider */
        $layoutProvider = $this->injectableFactory->create(LayoutProvider::class);
        $raw = $layoutProvider->get($scope, $name);

        $decoded = null;
        $decodeType = 'null';
        $jsonError = null;

        if ($raw !== null) {
            $decoded = json_decode($raw, true);
            $decodeType = gettype($decoded);
            $jsonError = json_last_error_msg();
        }

        $result = [
            'scope' => $scope,
            'name' => $name,
            'rawLength' => $raw !== null ? strlen($raw) : null,
            'decodeType' => $decodeType,
            'jsonError' => $jsonError,
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'E5',
                'location' => 'OAuthImap.php:534',
                'message' => 'Debug layout provider',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugLayoutProvider] ' . json_encode($result));

        return $result;
    }

    /**
     * @return array<string, mixed>
     */
    public function getActionDebugClientDefs(): array
    {
        $metadata = $this->getMetadata();

        $result = [
            'emailAccountRecordViews' => $metadata->get(['clientDefs', 'EmailAccount', 'recordViews']),
            'inboundEmailRecordViews' => $metadata->get(['clientDefs', 'InboundEmail', 'recordViews']),
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'E6',
                'location' => 'OAuthImap.php:584',
                'message' => 'Debug clientDefs recordViews',
                'data' => $result,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugClientDefs] ' . json_encode($result));

        return $result;
    }

    /**
     * @param Request $request
     * @return array<string, mixed>
     */
    public function getActionDebugClientPing(Request $request): array
    {
        $view = (string) ($request->getQueryParam('view') ?? '');
        $recordId = (string) ($request->getQueryParam('id') ?? '');
        $entityType = (string) ($request->getQueryParam('entityType') ?? '');
        $message = (string) ($request->getQueryParam('message') ?? '');

        $data = [
            'view' => $view,
            'id' => $recordId,
            'entityType' => $entityType,
            'message' => $message,
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'E1',
                'location' => 'OAuthImap.php:310',
                'message' => 'Client ping',
                'data' => $data,
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap DebugClientPing] ' . json_encode($data));

        return [
            'ok' => true,
        ];
    }

    private function getOAuthImapService(): OAuthImapService
    {
        /** @var OAuthImapService */
        return $this->injectableFactory->create(OAuthImapService::class);
    }

    private function getAccountOrFail(string $entityType, string $accountId): Entity
    {
        $account = $this->entityManager->getEntityById($entityType, $accountId);
        if (!$account) {
            throw new BadRequest('Email account not found.');
        }

        return $account;
    }

    private function assertAccess(Entity $account): void
    {
        $entityType = $account->getEntityType();
        if ($entityType === InboundEmail::ENTITY_TYPE) {
            if (!$this->user->isAdmin()) {
                throw new Forbidden('No access to inbound email account.');
            }
            return;
        }

        if ($entityType === EmailAccount::ENTITY_TYPE) {
            if (!$this->acl->checkEntity($account, 'edit')) {
                throw new Forbidden('No access to email account.');
            }
            return;
        }

        throw new Forbidden('No access to email account.');
    }
}
