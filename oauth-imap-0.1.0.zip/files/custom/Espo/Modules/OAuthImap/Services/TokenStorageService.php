<?php

namespace Espo\Modules\OAuthImap\Services;

use Espo\Core\Utils\Crypt;
use Espo\ORM\Entity;
use Espo\Modules\OAuthImap\Models\OAuthToken;

class TokenStorageService
{
    private Crypt $crypt;

    public function __construct(Crypt $crypt)
    {
        $this->crypt = $crypt;
    }

    public function storeTokens(Entity $account, OAuthToken $token): void
    {
        $account->set('oauthAccessToken', $this->crypt->encrypt($token->getAccessToken()));

        if ($token->getRefreshToken()) {
            $account->set('oauthRefreshToken', $this->crypt->encrypt($token->getRefreshToken()));
        }

        $account->set('oauthExpiresAt', $token->getExpiresAt());
        $account->set('oauthScopes', implode(' ', $token->getScopes()));
        $account->set('oauthStatus', 'connected');
        $account->set('oauthLastError', null);
    }

    public function readAccessToken(Entity $account): ?string
    {
        $encrypted = $account->get('oauthAccessToken');
        return $encrypted ? $this->crypt->decrypt($encrypted) : null;
    }

    public function readRefreshToken(Entity $account): ?string
    {
        $encrypted = $account->get('oauthRefreshToken');
        return $encrypted ? $this->crypt->decrypt($encrypted) : null;
    }
}
