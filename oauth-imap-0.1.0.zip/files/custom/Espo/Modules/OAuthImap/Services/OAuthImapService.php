<?php

namespace Espo\Modules\OAuthImap\Services;

use Espo\Core\Utils\Config;
use Espo\Core\Utils\Log;
use Espo\Entities\InboundEmail;
use Espo\Entities\EmailAccount;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\Modules\OAuthImap\Imap\ImapConnectorInterface;
use Espo\Modules\OAuthImap\OAuth\OAuthService;
use Espo\Modules\OAuthImap\OAuth\ProviderConfigResolver;
use Espo\Modules\OAuthImap\OAuth\ProviderFactory;
use Espo\Modules\OAuthImap\OAuth\StateManager;
use Espo\Modules\OAuthImap\OAuth\TokenRefreshDecider;
use RuntimeException;

class OAuthImapService
{
    private const ALLOWED_ENTITY_TYPES = [
        InboundEmail::ENTITY_TYPE,
        EmailAccount::ENTITY_TYPE,
    ];
    private EntityManager $entityManager;
    private Config $config;
    private Log $log;
    private ProviderFactory $providerFactory;
    private StateManager $stateManager;
    private TokenStorageService $tokenStorage;
    private TokenRefreshDecider $refreshDecider;
    private ImapConnectorInterface $imapConnector;

    public function __construct(
        EntityManager $entityManager,
        Config $config,
        Log $log,
        ProviderFactory $providerFactory,
        StateManager $stateManager,
        TokenStorageService $tokenStorage,
        TokenRefreshDecider $refreshDecider,
        ImapConnectorInterface $imapConnector
    ) {
        $this->entityManager = $entityManager;
        $this->config = $config;
        $this->log = $log;
        $this->providerFactory = $providerFactory;
        $this->stateManager = $stateManager;
        $this->tokenStorage = $tokenStorage;
        $this->refreshDecider = $refreshDecider;
        $this->imapConnector = $imapConnector;

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'P3',
                'location' => 'OAuthImapService.php:49',
                'message' => 'Service constructed',
                'data' => [
                    'vendorDir' => dirname(__DIR__, 2) . '/vendor',
                    'vendorExists' => is_dir(dirname(__DIR__, 2) . '/vendor'),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
    }

    public function generateAuthUrl(string $accountId, bool $usePkce = true, string $entityType = InboundEmail::ENTITY_TYPE): array
    {
        $account = $this->getAccount($entityType, $accountId);
        $account->set('oauthStatus', 'pending');

        $oauthService = $this->createOAuthService();
        $result = $oauthService->buildAuthorizationUrl($account, $usePkce);
        $this->entityManager->saveEntity($account);

        return $result;
    }

    public function handleCallback(string $state, string $code): void
    {
        $accountId = $this->stateManager->extractAccountId($state);
        $entityType = $this->stateManager->extractEntityType($state);
        $account = $this->getAccount($entityType, $accountId);
        $this->stateManager->validateState($account, $state);

        $oauthService = $this->createOAuthService();
        $token = $oauthService->exchangeCode($account, $code);
        $this->tokenStorage->storeTokens($account, $token);
        $this->entityManager->saveEntity($account);
    }

    public function testImap(string $accountId, string $entityType = InboundEmail::ENTITY_TYPE): array
    {
        $account = $this->getAccount($entityType, $accountId);
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H2',
                'location' => 'OAuthImapService.php:99',
                'message' => 'Test IMAP start',
                'data' => [
                    'entityType' => $account->getEntityType(),
                    'accountId' => $account->getId(),
                    'provider' => (string) $account->get('oauthProvider'),
                    'hasHost' => (string) $account->get('host') !== '',
                    'hasOauthEmail' => (string) $account->get('oauthEmail') !== '',
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap TestImap] start entityType=' . $account->getEntityType() . ' accountId=' . $account->getId());

        try {
            $this->refreshTokenIfNeeded($account);

            $accessToken = $this->tokenStorage->readAccessToken($account);
            if (!$accessToken) {
                throw new RuntimeException('Access token missing.');
            }
            error_log('[OAuthImap TestImap] accessTokenPresent=1');
            $tokenParts = explode('.', $accessToken);
            $tokenClaims = null;
            if (count($tokenParts) === 3) {
                $payload = strtr($tokenParts[1], '-_', '+/');
                $decoded = base64_decode($payload . str_repeat('=', (4 - strlen($payload) % 4) % 4));
                if ($decoded !== false) {
                    $tokenClaims = json_decode($decoded, true);
                }
            }
            $claimSummary = [
                'aud' => is_array($tokenClaims) ? ($tokenClaims['aud'] ?? null) : null,
                'scp' => is_array($tokenClaims) ? ($tokenClaims['scp'] ?? null) : null,
                'roles' => is_array($tokenClaims) ? ($tokenClaims['roles'] ?? null) : null,
                'iss' => is_array($tokenClaims) ? ($tokenClaims['iss'] ?? null) : null,
                'tid' => is_array($tokenClaims) ? ($tokenClaims['tid'] ?? null) : null,
            ];
            // #region agent log
            @file_put_contents(
                'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
                json_encode([
                    'sessionId' => 'debug-session',
                    'runId' => 'run1',
                    'hypothesisId' => 'H11',
                    'location' => 'OAuthImapService.php:122',
                    'message' => 'Access token claim summary',
                    'data' => $claimSummary,
                    'timestamp' => (int) (microtime(true) * 1000),
                ]) . PHP_EOL,
                FILE_APPEND
            );
            // #endregion agent log
            error_log('[OAuthImap TestImap] tokenClaims aud=' . (string) ($claimSummary['aud'] ?? '')
                . ' iss=' . (string) ($claimSummary['iss'] ?? '')
                . ' scp=' . (string) ($claimSummary['scp'] ?? '')
                . ' roles=' . (is_array($claimSummary['roles'] ?? null) ? implode(',', $claimSummary['roles']) : (string) ($claimSummary['roles'] ?? ''))
            );

            $diagnostics = $this->imapConnector->testConnection($account, $accessToken);
            error_log('[OAuthImap TestImap] connectorReturn success=' . ($diagnostics->isSuccess() ? '1' : '0'));

            // #region agent log
            @file_put_contents(
                'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
                json_encode([
                    'sessionId' => 'debug-session',
                    'runId' => 'run1',
                    'hypothesisId' => 'H3',
                    'location' => 'OAuthImapService.php:131',
                    'message' => 'Test IMAP diagnostics',
                    'data' => [
                        'success' => $diagnostics->isSuccess(),
                        'capabilitiesCount' => is_array($diagnostics->getCapabilities()) ? count($diagnostics->getCapabilities()) : null,
                        'greetingLength' => is_string($diagnostics->getGreeting()) ? strlen($diagnostics->getGreeting()) : null,
                    ],
                    'timestamp' => (int) (microtime(true) * 1000),
                ]) . PHP_EOL,
                FILE_APPEND
            );
            // #endregion agent log
        } catch (\Throwable $e) {
            // #region agent log
            @file_put_contents(
                'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
                json_encode([
                    'sessionId' => 'debug-session',
                    'runId' => 'run1',
                    'hypothesisId' => 'H6',
                    'location' => 'OAuthImapService.php:147',
                    'message' => 'Test IMAP exception',
                    'data' => [
                        'errorClass' => get_class($e),
                        'errorCode' => $e->getCode(),
                        'entityType' => $account->getEntityType(),
                    ],
                    'timestamp' => (int) (microtime(true) * 1000),
                ]) . PHP_EOL,
                FILE_APPEND
            );
            // #endregion agent log
            error_log('[OAuthImap TestImap] exception errorClass=' . get_class($e) . ' code=' . $e->getCode());
            throw $e;
        }

        return [
            'success' => $diagnostics->isSuccess(),
            'message' => $diagnostics->getMessage(),
            'capabilities' => $diagnostics->getCapabilities(),
            'greeting' => $diagnostics->getGreeting(),
        ];
    }

    public function disconnect(string $accountId, string $entityType = InboundEmail::ENTITY_TYPE): void
    {
        $account = $this->getAccount($entityType, $accountId);
        $account->set('oauthAccessToken', null);
        $account->set('oauthRefreshToken', null);
        $account->set('oauthExpiresAt', null);
        $account->set('oauthStatus', 'disconnected');
        $account->set('oauthLastError', null);
        $account->set('oauthStateNonce', null);
        $account->set('oauthCodeVerifier', null);

        $this->entityManager->saveEntity($account);
    }

    public function getValidAccessToken(Entity $account): string
    {
        $refreshToken = $this->tokenStorage->readRefreshToken($account);
        $expiresAtRaw = $account->get('oauthExpiresAt');
        $expiresAt = $expiresAtRaw !== null ? (int) $expiresAtRaw : null;
        $now = time();

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'X4',
                'location' => 'OAuthImapService.php:111',
                'message' => 'Token refresh check',
                'data' => [
                    'entityType' => $account->getEntityType(),
                    'hasRefreshToken' => $refreshToken ? true : false,
                    'expiresAt' => $expiresAt,
                    'now' => $now,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        if ($refreshToken && $this->refreshDecider->shouldRefresh($expiresAt, $now)) {
            $oauthService = $this->createOAuthService();
            try {
                $token = $oauthService->refreshToken($account, $refreshToken);
                $this->tokenStorage->storeTokens($account, $token);
                $this->entityManager->saveEntity($account);
            } catch (\Throwable $e) {
                $account->set('oauthStatus', 'error');
                $account->set('oauthLastError', 'Token refresh failed.');
                $this->entityManager->saveEntity($account);
                $this->log->error('OAuth token refresh failed.', [
                    'accountId' => $account->getId(),
                    'error' => $e->getMessage(),
                ]);
                throw $e;
            }
        }

        $accessToken = $this->tokenStorage->readAccessToken($account);
        if (!$accessToken) {
            throw new RuntimeException('Access token missing.');
        }

        return $accessToken;
    }

    /**
     * @return string[]
     */
    public function getEffectiveScopes(string $accountId, string $entityType = InboundEmail::ENTITY_TYPE): array
    {
        $account = $this->getAccount($entityType, $accountId);
        $resolver = new ProviderConfigResolver($this->getProviderDefaults());
        $config = $resolver->resolveForAccount($account);

        return $config->getScopes();
    }

    private function refreshTokenIfNeeded(Entity $account): void
    {
        $this->getValidAccessToken($account);
    }

    private function getAccount(string $entityType, string $accountId): Entity
    {
        if (!in_array($entityType, self::ALLOWED_ENTITY_TYPES, true)) {
            throw new RuntimeException('Unsupported account entity type.');
        }

        /** @var ?Entity $account */
        $account = $this->entityManager->getEntityById($entityType, $accountId);
        if (!$account) {
            throw new RuntimeException('Email account not found.');
        }

        return $account;
    }

    private function createOAuthService(): OAuthService
    {
        $resolver = new ProviderConfigResolver($this->getProviderDefaults());
        return new OAuthService($this->providerFactory, $resolver, $this->stateManager);
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function getProviderDefaults(): array
    {
        $redirectUri = (string) ($this->config->get('oauthImapRedirectUri')
            ?: ($this->config->get('siteUrl') . '?entryPoint=oauthImapCallback'));

        return [
            'google' => [
                'clientId' => (string) $this->config->get('oauthImapGoogleClientId'),
                'clientSecret' => (string) $this->config->get('oauthImapGoogleClientSecret'),
                'scopes' => (string) $this->config->get('oauthImapGoogleScopes'),
                'redirectUri' => $redirectUri,
            ],
            'microsoft' => [
                'clientId' => (string) $this->config->get('oauthImapMicrosoftClientId'),
                'clientSecret' => (string) $this->config->get('oauthImapMicrosoftClientSecret'),
                'tenantId' => (string) $this->config->get('oauthImapMicrosoftTenantId'),
                'scopes' => (string) $this->config->get('oauthImapMicrosoftScopes'),
                'redirectUri' => $redirectUri,
            ],
        ];
    }
}
