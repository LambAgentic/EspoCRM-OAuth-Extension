<?php

namespace Espo\Modules\OAuthImap;

use Espo\Core\Binding\Binder;
use Espo\Core\Binding\BindingProcessor;
use Espo\Modules\OAuthImap\Imap\ImapConnectorInterface;
use Espo\Modules\OAuthImap\Imap\StreamImapConnector;

class Binding implements BindingProcessor
{
    public function process(Binder $binder): void
    {
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'P1',
                'location' => 'Binding.php:14',
                'message' => 'Binding process entry',
                'data' => [
                    'phpVersion' => PHP_VERSION,
                    'module' => __NAMESPACE__,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        $binder->bindImplementation(ImapConnectorInterface::class, StreamImapConnector::class);

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'P2',
                'location' => 'Binding.php:30',
                'message' => 'Binding process completed',
                'data' => [
                    'imapInterface' => ImapConnectorInterface::class,
                    'imapImpl' => StreamImapConnector::class,
                    'streamConnectorExists' => class_exists(StreamImapConnector::class),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
    }
}
