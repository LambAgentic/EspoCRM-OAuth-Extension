<?php

namespace Espo\Modules\OAuthImap\Imap;

use RuntimeException;

class ImapClient
{
    private $socket;
    private int $tagCounter = 1;

    public function connect(ImapConnectionConfig $config): string
    {
        $scheme = $config->useTls() ? 'ssl' : 'tcp';
        $address = sprintf('%s://%s:%d', $scheme, $config->getHost(), $config->getPort());
        $timeout = $config->getTimeout();

        $socket = @stream_socket_client($address, $errno, $errstr, $timeout);
        if (!$socket) {
            throw new RuntimeException('IMAP connection failed: ' . $errstr);
        }

        stream_set_timeout($socket, $timeout);
        $this->socket = $socket;

        return $this->readLine();
    }

    public function capability(): array
    {
        $response = $this->sendCommand('CAPABILITY');
        $capabilities = [];

        foreach ($response['lines'] as $line) {
            if (stripos($line, '* CAPABILITY') === 0) {
                $parts = explode(' ', trim($line));
                $capabilities = array_slice($parts, 2);
            }
        }

        return $capabilities;
    }

    public function authenticateXoauth2(string $xoauth2): void
    {
        $tag = $this->nextTag();
        $this->writeLine($tag . ' AUTHENTICATE XOAUTH2');

        $line = $this->readLine();
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H10',
                'location' => 'ImapClient.php:53',
                'message' => 'IMAP AUTH challenge line',
                'data' => [
                    'linePrefix' => substr($line, 0, 2),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        if (strpos($line, '+') === 0) {
            $this->writeLine($xoauth2);
        }

        $response = $this->readUntilTagged($tag);
        $tagged = $response['tagged'] ?? '';

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H8',
                'location' => 'ImapClient.php:60',
                'message' => 'IMAP XOAUTH2 tagged response',
                'data' => [
                    'tagged' => $tagged,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        error_log('[OAuthImap TestImap] authTagged=' . ($tagged ?: ''));
        if (stripos($tagged, $tag . ' OK') !== 0) {
            throw new RuntimeException('IMAP AUTH failed: ' . $tagged);
        }
    }

    public function selectInbox(): void
    {
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'S1',
                'location' => 'ImapClient.php:59',
                'message' => 'Selecting INBOX',
                'data' => [
                    'command' => 'SELECT INBOX',
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap TestImap] selectInbox command=SELECT INBOX');
        $this->sendCommand('SELECT INBOX');
    }

    public function logout(): void
    {
        $this->sendCommand('LOGOUT', false);
        if ($this->socket) {
            fclose($this->socket);
        }
    }

    public function sendCommand(string $command, bool $expectOk = true): array
    {
        $tag = $this->nextTag();
        $this->writeLine($tag . ' ' . $command);
        $response = $this->readUntilTagged($tag);

        if ($expectOk && stripos($response['tagged'], $tag . ' OK') !== 0) {
            // #region agent log
            @file_put_contents(
                'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
                json_encode([
                    'sessionId' => 'debug-session',
                    'runId' => 'run1',
                    'hypothesisId' => 'S2',
                    'location' => 'ImapClient.php:78',
                    'message' => 'IMAP command failed',
                    'data' => [
                        'command' => $command,
                        'tagged' => $response['tagged'] ?? null,
                        'linesSample' => array_slice($response['lines'] ?? [], -5),
                    ],
                    'timestamp' => (int) (microtime(true) * 1000),
                ]) . PHP_EOL,
                FILE_APPEND
            );
            // #endregion agent log
            $linesSample = array_slice($response['lines'] ?? [], -5);
            error_log('[OAuthImap TestImap] imapCommandFailed command=' . $command . ' tagged=' . ($response['tagged'] ?? '')
                . ' linesSample=' . json_encode($linesSample));
            throw new RuntimeException('IMAP command failed: ' . $response['tagged']);
        }

        return $response;
    }

    private function nextTag(): string
    {
        return 'A' . str_pad((string) $this->tagCounter++, 4, '0', STR_PAD_LEFT);
    }

    private function readUntilTagged(string $tag): array
    {
        $lines = [];
        while (true) {
            $line = $this->readLine();
            $lines[] = $line;
            if (strpos($line, $tag . ' ') === 0) {
                return [
                    'lines' => $lines,
                    'tagged' => $line,
                ];
            }
        }
    }

    private function readLine(): string
    {
        if (!$this->socket) {
            throw new RuntimeException('IMAP socket not connected.');
        }

        $line = fgets($this->socket);
        if ($line === false) {
            throw new RuntimeException('IMAP read failed.');
        }

        return rtrim($line, "\r\n");
    }

    private function writeLine(string $line): void
    {
        if (!$this->socket) {
            throw new RuntimeException('IMAP socket not connected.');
        }

        fwrite($this->socket, $line . "\r\n");
    }
}
