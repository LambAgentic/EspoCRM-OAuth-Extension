<?php

namespace Espo\Modules\OAuthImap\Imap\Protocol;

use Espo\Modules\OAuthImap\Imap\Xoauth2AuthStringBuilder;
use Laminas\Mail\Protocol\Imap as LaminasImap;
use Laminas\Mail\Protocol\Exception\RuntimeException as ProtocolRuntimeException;

class Xoauth2ImapProtocol extends LaminasImap
{
    private Xoauth2AuthStringBuilder $builder;

    public function __construct(?Xoauth2AuthStringBuilder $builder = null)
    {
        parent::__construct();
        $this->builder = $builder ?: new Xoauth2AuthStringBuilder();
    }

    public function authenticateXoauth2(string $email, string $accessToken): void
    {
        $authString = $this->builder->build($email, $accessToken);

        $tag = null;
        $this->sendRequest('AUTHENTICATE XOAUTH2', [$authString], $tag);

        $response = $this->readResponse($tag, true);
        if (!$response) {
            throw new ProtocolRuntimeException('XOAUTH2 authentication failed.');
        }
    }
}
