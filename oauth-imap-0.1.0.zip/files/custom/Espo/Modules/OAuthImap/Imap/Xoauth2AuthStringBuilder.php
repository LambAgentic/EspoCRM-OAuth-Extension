<?php

namespace Espo\Modules\OAuthImap\Imap;

class Xoauth2AuthStringBuilder
{
    public function build(string $email, string $accessToken): string
    {
        $value = "user={$email}\x01auth=Bearer {$accessToken}\x01\x01";
        return base64_encode($value);
    }
}
