<?php

namespace Espo\Modules\OAuthImap\Imap;

use Espo\Entities\InboundEmail;
use Espo\Entities\EmailAccount;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;
use Espo\Modules\OAuthImap\Imap\Protocol\Xoauth2ImapProtocol;
use Espo\Modules\OAuthImap\Services\OAuthImapService;
use RuntimeException;

class Xoauth2ImapHandler
{
    public function __construct(
        private EntityManager $entityManager,
        private OAuthImapService $oauthImapService
    ) {}

    /**
     * @param string $id EmailAccount or InboundEmail ID.
     * @param array<string, mixed> $params
     */
    public function prepareProtocol(string $id, array $params): Xoauth2ImapProtocol
    {
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'X1',
                'location' => 'Xoauth2ImapHandler.php:24',
                'message' => 'prepareProtocol entry',
                'data' => [
                    'id' => $id,
                    'hasHost' => !empty($params['host'] ?? null),
                    'hasPort' => !empty($params['port'] ?? null),
                    'security' => $params['security'] ?? ($params['ssl'] ?? null),
                    'hasUsername' => !empty($params['username'] ?? null),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        /** @var ?Entity $account */
        $account = $this->entityManager->getEntityById(EmailAccount::ENTITY_TYPE, $id)
            ?? $this->entityManager->getEntityById(InboundEmail::ENTITY_TYPE, $id);
        if (!$account) {
            throw new RuntimeException('Email account not found.');
        }

        $email = (string) ($account->get('oauthEmail') ?: ($params['username'] ?? '') ?: ($params['emailAddress'] ?? ''));
        if ($email === '') {
            throw new RuntimeException('OAuth email is missing.');
        }

        $host = $params['host'] ?? null;
        $port = $params['port'] ?? null;
        $security = $params['security'] ?? ($params['ssl'] ?? null);

        if (!$host || !$port) {
            throw new RuntimeException('IMAP host or port missing.');
        }

        $accessToken = $this->oauthImapService->getValidAccessToken($account);

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'X2',
                'location' => 'Xoauth2ImapHandler.php:55',
                'message' => 'Token fetched',
                'data' => [
                    'tokenLength' => strlen($accessToken),
                    'entityType' => $account->getEntityType(),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        $protocol = new Xoauth2ImapProtocol();
        $protocol->connect((string) $host, (int) $port, $security ?: false);
        $protocol->authenticateXoauth2($email, $accessToken);

        return $protocol;
    }
}
