<?php

namespace Espo\Modules\OAuthImap\Imap;

use Espo\ORM\Entity;

interface ImapConnectorInterface
{
    public function testConnection(Entity $account, string $accessToken): ImapDiagnostics;
}
