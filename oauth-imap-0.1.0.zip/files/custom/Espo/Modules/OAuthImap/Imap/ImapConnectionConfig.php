<?php

namespace Espo\Modules\OAuthImap\Imap;

class ImapConnectionConfig
{
    private string $host;
    private int $port;
    private bool $tls;
    private int $timeout;

    public function __construct(string $host, int $port = 993, bool $tls = true, int $timeout = 10)
    {
        $this->host = $host;
        $this->port = $port;
        $this->tls = $tls;
        $this->timeout = $timeout;
    }

    public function getHost(): string
    {
        return $this->host;
    }

    public function getPort(): int
    {
        return $this->port;
    }

    public function useTls(): bool
    {
        return $this->tls;
    }

    public function getTimeout(): int
    {
        return $this->timeout;
    }
}
