<?php

namespace Espo\Modules\OAuthImap\Imap;

use Espo\ORM\Entity;
use RuntimeException;

class StreamImapConnector implements ImapConnectorInterface
{
    private ImapClient $client;
    private Xoauth2AuthStringBuilder $builder;

    public function __construct(?ImapClient $client = null, ?Xoauth2AuthStringBuilder $builder = null)
    {
        $this->client = $client ?: new ImapClient();
        $this->builder = $builder ?: new Xoauth2AuthStringBuilder();
    }

    public function testConnection(Entity $account, string $accessToken): ImapDiagnostics
    {
        $host = (string) $account->get('host');
        $port = (int) ($account->get('port') ?: 993);
        $security = $account->get('security');
        $tls = ($security === 'SSL' || $security === 'TLS');
        $email = (string) ($account->get('oauthEmail') ?: $account->get('username') ?: $account->get('emailAddress'));

        if (!$host || !$email) {
            throw new RuntimeException('IMAP host or OAuth email missing.');
        }

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'X3',
                'location' => 'StreamImapConnector.php:33',
                'message' => 'IMAP test parameters',
                'data' => [
                    'host' => $host,
                    'port' => $port,
                    'security' => $security,
                    'tls' => $tls,
                    'emailPresent' => $email !== '',
                    'tokenLength' => strlen($accessToken),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap TestImap] imapParams host=' . $host . ' port=' . $port . ' tls=' . ($tls ? '1' : '0') . ' emailPresent=' . ($email !== '' ? '1' : '0'));

        $config = new ImapConnectionConfig($host, $port, $tls, 12);
        $greeting = $this->client->connect($config);
        $capabilities = $this->client->capability();

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H2',
                'location' => 'StreamImapConnector.php:60',
                'message' => 'IMAP connected and capabilities fetched',
                'data' => [
                    'capabilitiesCount' => is_array($capabilities) ? count($capabilities) : null,
                    'greetingLength' => is_string($greeting) ? strlen($greeting) : null,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap TestImap] imapConnected capabilitiesCount=' . (is_array($capabilities) ? count($capabilities) : 0));
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H9',
                'location' => 'StreamImapConnector.php:66',
                'message' => 'IMAP capability flags',
                'data' => [
                    'hasXoauth2' => is_array($capabilities) && in_array('AUTH=XOAUTH2', $capabilities, true),
                    'hasOauthBearer' => is_array($capabilities) && in_array('AUTH=OAUTHBEARER', $capabilities, true),
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log

        $xoauth2 = $this->builder->build($email, $accessToken);
        try {
            $this->client->authenticateXoauth2($xoauth2);
            $this->client->selectInbox();
            $this->client->logout();
        } catch (\Throwable $e) {
            // #region agent log
            @file_put_contents(
                'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
                json_encode([
                    'sessionId' => 'debug-session',
                    'runId' => 'run1',
                    'hypothesisId' => 'H7',
                    'location' => 'StreamImapConnector.php:69',
                    'message' => 'IMAP auth/select failed',
                    'data' => [
                        'errorClass' => get_class($e),
                        'errorMessage' => $e->getMessage(),
                    ],
                    'timestamp' => (int) (microtime(true) * 1000),
                ]) . PHP_EOL,
                FILE_APPEND
            );
            // #endregion agent log
            error_log('[OAuthImap TestImap] imapAuthFailed errorClass=' . get_class($e) . ' message=' . $e->getMessage());
            throw $e;
        }

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H3',
                'location' => 'StreamImapConnector.php:77',
                'message' => 'IMAP XOAUTH2 authenticated',
                'data' => [
                    'authenticated' => true,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap TestImap] imapAuthenticated=1');

        return new ImapDiagnostics(true, 'IMAP authentication successful.', $capabilities, $greeting);
    }
}
