<?php

namespace Espo\Modules\OAuthImap\Imap;

class ImapDiagnostics
{
    private bool $success;
    private string $message;
    /** @var string[] */
    private array $capabilities;
    private ?string $greeting;

    /**
     * @param string[] $capabilities
     */
    public function __construct(bool $success, string $message, array $capabilities = [], ?string $greeting = null)
    {
        $this->success = $success;
        $this->message = $message;
        $this->capabilities = $capabilities;
        $this->greeting = $greeting;
    }

    public function isSuccess(): bool
    {
        return $this->success;
    }

    public function getMessage(): string
    {
        return $this->message;
    }

    /**
     * @return string[]
     */
    public function getCapabilities(): array
    {
        return $this->capabilities;
    }

    public function getGreeting(): ?string
    {
        return $this->greeting;
    }
}
