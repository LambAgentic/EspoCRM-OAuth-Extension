<?php

namespace Espo\Modules\OAuthImap;

$autoload = __DIR__ . '/vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
}

class Module
{
    // Module bootstrap hook placeholder.
}
