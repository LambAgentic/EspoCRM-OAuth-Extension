<?php

namespace Espo\Modules\OAuthImap;

class Module
{
    // TODO: ESPO module bootstrap hooks if needed.
}
