<?php

namespace Espo\Modules\OAuthImap\OAuth;

use Espo\ORM\Entity;
use Espo\Modules\OAuthImap\Models\OAuthToken;

class OAuthService
{
    private ProviderFactory $providerFactory;
    private ProviderConfigResolver $configResolver;
    private StateManager $stateManager;

    public function __construct(
        ProviderFactory $providerFactory,
        ProviderConfigResolver $configResolver,
        StateManager $stateManager
    ) {
        $this->providerFactory = $providerFactory;
        $this->configResolver = $configResolver;
        $this->stateManager = $stateManager;
    }

    public function buildAuthorizationUrl(Entity $account, bool $usePkce): array
    {
        $config = $this->configResolver->resolveForAccount($account);
        $state = $this->stateManager->generateState($account);

        $codeChallenge = null;
        if ($usePkce) {
            $verifier = $this->stateManager->generatePkceCodeVerifier($account);
            $codeChallenge = $this->stateManager->buildPkceCodeChallenge($verifier);
        }

        $provider = $this->providerFactory->create($config->getProvider());
        $url = $provider->getAuthorizationUrl($config, $state, $codeChallenge);
        $urlParts = parse_url($url);
        $urlHost = $urlParts['host'] ?? null;
        $urlPath = $urlParts['path'] ?? null;
        $urlQuery = $urlParts['query'] ?? null;

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H16',
                'location' => 'OAuthService.php:35',
                'message' => 'Authorization URL generated',
                'data' => [
                    'host' => $urlHost,
                    'path' => $urlPath,
                    'hasQuery' => $urlQuery !== null,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap MicrosoftOAuth] authUrl host=' . ($urlHost ?: '') . ' path=' . ($urlPath ?: ''));

        return [
            'url' => $url,
            'state' => $state,
        ];
    }

    public function exchangeCode(Entity $account, string $code): OAuthToken
    {
        $config = $this->configResolver->resolveForAccount($account);
        $provider = $this->providerFactory->create($config->getProvider());
        $codeVerifier = $account->get('oauthCodeVerifier');

        return $provider->exchangeCode($config, $code, $codeVerifier ?: null);
    }

    public function refreshToken(Entity $account, string $refreshToken): OAuthToken
    {
        $config = $this->configResolver->resolveForAccount($account);
        $provider = $this->providerFactory->create($config->getProvider());

        return $provider->refreshAccessToken($config, $refreshToken);
    }
}
