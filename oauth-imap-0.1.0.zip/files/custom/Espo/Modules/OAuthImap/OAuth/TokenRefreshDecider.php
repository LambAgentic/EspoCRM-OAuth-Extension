<?php

namespace Espo\Modules\OAuthImap\OAuth;

class TokenRefreshDecider
{
    public function shouldRefresh(?int $expiresAt, int $now, int $thresholdSeconds = 120): bool
    {
        if (!$expiresAt) {
            return false;
        }

        return $expiresAt <= ($now + $thresholdSeconds);
    }
}
