<?php

namespace Espo\Modules\OAuthImap\OAuth\Provider;

use Espo\Modules\OAuthImap\Models\OAuthProviderConfig;
use Espo\Modules\OAuthImap\Models\OAuthToken;

interface OAuthProviderInterface
{
    public function getAuthorizationUrl(OAuthProviderConfig $config, string $state, ?string $codeChallenge = null): string;

    public function exchangeCode(OAuthProviderConfig $config, string $code, ?string $codeVerifier = null): OAuthToken;

    public function refreshAccessToken(OAuthProviderConfig $config, string $refreshToken): OAuthToken;
}
