<?php

namespace Espo\Modules\OAuthImap\OAuth\Provider;

use Espo\Modules\OAuthImap\Models\OAuthProviderConfig;
use Espo\Modules\OAuthImap\Models\OAuthToken;
use League\OAuth2\Client\Provider\Google;

class GoogleProviderAdapter implements OAuthProviderInterface
{
    private function buildProvider(OAuthProviderConfig $config): Google
    {
        return new Google([
            'clientId' => $config->getClientId(),
            'clientSecret' => $config->getClientSecret(),
            'redirectUri' => $config->getRedirectUri(),
        ]);
    }

    public function getAuthorizationUrl(OAuthProviderConfig $config, string $state, ?string $codeChallenge = null): string
    {
        $provider = $this->buildProvider($config);
        $options = [
            'state' => $state,
            'access_type' => 'offline',
            'prompt' => 'consent',
            'scope' => $config->getScopes(),
        ];

        if ($codeChallenge) {
            $options['code_challenge'] = $codeChallenge;
            $options['code_challenge_method'] = 'S256';
        }

        return $provider->getAuthorizationUrl($options);
    }

    public function exchangeCode(OAuthProviderConfig $config, string $code, ?string $codeVerifier = null): OAuthToken
    {
        $provider = $this->buildProvider($config);
        $options = [
            'code' => $code,
            'redirect_uri' => $config->getRedirectUri(),
        ];

        if ($codeVerifier) {
            $options['code_verifier'] = $codeVerifier;
        }

        $token = $provider->getAccessToken('authorization_code', $options);
        return OAuthToken::fromLeagueToken($token);
    }

    public function refreshAccessToken(OAuthProviderConfig $config, string $refreshToken): OAuthToken
    {
        $provider = $this->buildProvider($config);
        $token = $provider->getAccessToken('refresh_token', ['refresh_token' => $refreshToken]);
        return OAuthToken::fromLeagueToken($token);
    }
}
