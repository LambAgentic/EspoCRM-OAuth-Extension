<?php

namespace Espo\Modules\OAuthImap\OAuth\Provider;

use Espo\Modules\OAuthImap\Models\OAuthProviderConfig;
use Espo\Modules\OAuthImap\Models\OAuthToken;
use League\OAuth2\Client\Provider\GenericProvider;
use TheNetworg\OAuth2\Client\Provider\Azure;

class MicrosoftProviderAdapter implements OAuthProviderInterface
{
    private function shouldUseV2(array $scopes): bool
    {
        foreach ($scopes as $scope) {
            if (stripos($scope, 'https://outlook.office365.com/') === 0) {
                return true;
            }
            if (stripos($scope, 'IMAP.AccessAsUser.All') !== false) {
                return true;
            }
        }
        return false;
    }

    /**
     * Keep only OIDC scopes when using v1 resource flow.
     *
     * @param string[] $scopes
     * @return string[]
     */
    private function normalizeScopesForResource(array $scopes): array
    {
        $allowed = ['openid', 'profile', 'email', 'offline_access'];
        $result = [];
        foreach ($scopes as $scope) {
            if (in_array(strtolower($scope), $allowed, true)) {
                $result[] = $scope;
            }
        }
        return $result;
    }

    private function resolveResource(array $scopes): ?string
    {
        foreach ($scopes as $scope) {
            if (stripos($scope, 'https://outlook.office365.com/') === 0) {
                return 'https://outlook.office365.com/';
            }
        }

        foreach ($scopes as $scope) {
            if (stripos($scope, 'imap.accessasuser.all') !== false) {
                return 'https://outlook.office365.com/';
            }
        }

        return null;
    }

    private function buildV2Provider(OAuthProviderConfig $config): GenericProvider
    {
        $tenant = $config->getTenantId() ?: 'common';
        $base = 'https://login.microsoftonline.com/' . $tenant . '/oauth2/v2.0';

        return new GenericProvider([
            'clientId' => $config->getClientId(),
            'clientSecret' => $config->getClientSecret(),
            'redirectUri' => $config->getRedirectUri(),
            'urlAuthorize' => $base . '/authorize',
            'urlAccessToken' => $base . '/token',
            'urlResourceOwnerDetails' => 'https://graph.microsoft.com/oidc/userinfo',
        ]);
    }

    private function buildProvider(OAuthProviderConfig $config): Azure
    {
        $tenant = $config->getTenantId() ?: 'common';
        $options = [
            'clientId' => $config->getClientId(),
            'clientSecret' => $config->getClientSecret(),
            'redirectUri' => $config->getRedirectUri(),
            'tenant' => $tenant,
        ];

        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H15',
                'location' => 'MicrosoftProviderAdapter.php:35',
                'message' => 'Build Azure provider',
                'data' => [
                    'tenant' => $tenant,
                    'urlAuthorize' => $options['urlAuthorize'] ?? null,
                    'urlAccessToken' => $options['urlAccessToken'] ?? null,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap MicrosoftOAuth] provider tenant=' . $tenant . ' useV2=0');

        return new Azure([
            ...$options,
        ]);
    }

    public function getAuthorizationUrl(OAuthProviderConfig $config, string $state, ?string $codeChallenge = null): string
    {
        $useV2 = $this->shouldUseV2($config->getScopes());
        $provider = $useV2 ? $this->buildV2Provider($config) : $this->buildProvider($config);
        $resource = $useV2 ? null : $this->resolveResource($config->getScopes());
        $scopes = $resource ? $this->normalizeScopesForResource($config->getScopes()) : $config->getScopes();
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H12',
                'location' => 'MicrosoftProviderAdapter.php:29',
                'message' => 'Auth URL resource resolution',
                'data' => [
                    'scopeCount' => count($config->getScopes()),
                    'resource' => $resource,
                    'useV2' => $useV2,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap MicrosoftOAuth] auth mode=' . ($useV2 ? 'v2' : 'v1') . ' resource=' . ($resource ?: 'null') . ' scopes=' . implode(' ', $scopes));
        $options = [
            'state' => $state,
            'scope' => $useV2 ? implode(' ', $scopes) : $scopes,
        ];

        if ($resource) {
            $options['resource'] = $resource;
        }

        if ($codeChallenge) {
            $options['code_challenge'] = $codeChallenge;
            $options['code_challenge_method'] = 'S256';
        }

        return $provider->getAuthorizationUrl($options);
    }

    public function exchangeCode(OAuthProviderConfig $config, string $code, ?string $codeVerifier = null): OAuthToken
    {
        $useV2 = $this->shouldUseV2($config->getScopes());
        $provider = $useV2 ? $this->buildV2Provider($config) : $this->buildProvider($config);
        $resource = $useV2 ? null : $this->resolveResource($config->getScopes());
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H13',
                'location' => 'MicrosoftProviderAdapter.php:59',
                'message' => 'Exchange code resource resolution',
                'data' => [
                    'resource' => $resource,
                    'useV2' => $useV2,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap MicrosoftOAuth] exchange mode=' . ($useV2 ? 'v2' : 'v1') . ' resource=' . ($resource ?: 'null'));
        $options = [
            'code' => $code,
            'redirect_uri' => $config->getRedirectUri(),
        ];

        if ($resource) {
            $options['resource'] = $resource;
        }

        if ($codeVerifier) {
            $options['code_verifier'] = $codeVerifier;
        }

        $token = $provider->getAccessToken('authorization_code', $options);
        return OAuthToken::fromLeagueToken($token);
    }

    public function refreshAccessToken(OAuthProviderConfig $config, string $refreshToken): OAuthToken
    {
        $useV2 = $this->shouldUseV2($config->getScopes());
        $provider = $useV2 ? $this->buildV2Provider($config) : $this->buildProvider($config);
        $options = ['refresh_token' => $refreshToken];
        $resource = $useV2 ? null : $this->resolveResource($config->getScopes());
        // #region agent log
        @file_put_contents(
            'c:\\Users\\Caleb\\OneDrive\\Documents\\GitHub\\Oauth2-Email-extension\\.cursor\\debug.log',
            json_encode([
                'sessionId' => 'debug-session',
                'runId' => 'run1',
                'hypothesisId' => 'H14',
                'location' => 'MicrosoftProviderAdapter.php:83',
                'message' => 'Refresh token resource resolution',
                'data' => [
                    'resource' => $resource,
                    'useV2' => $useV2,
                ],
                'timestamp' => (int) (microtime(true) * 1000),
            ]) . PHP_EOL,
            FILE_APPEND
        );
        // #endregion agent log
        error_log('[OAuthImap MicrosoftOAuth] refresh mode=' . ($useV2 ? 'v2' : 'v1') . ' resource=' . ($resource ?: 'null'));
        if ($resource) {
            $options['resource'] = $resource;
        }
        $token = $provider->getAccessToken('refresh_token', $options);
        return OAuthToken::fromLeagueToken($token);
    }
}
