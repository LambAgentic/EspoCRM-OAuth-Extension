<?php

namespace Espo\Modules\OAuthImap\OAuth;

use Espo\ORM\Entity;
use RuntimeException;

class StateManager
{
    public function generateState(Entity $account): string
    {
        $nonce = $this->randomString(32);
        $account->set('oauthStateNonce', $nonce);

        $payload = [
            'accountId' => $account->getId(),
            'entityType' => $account->getEntityType(),
            'nonce' => $nonce,
        ];

        return $this->base64UrlEncode(json_encode($payload, JSON_THROW_ON_ERROR));
    }

    public function validateState(Entity $account, string $state): void
    {
        $payload = $this->decodeState($state);
        $nonce = $payload['nonce'] ?? null;
        if (!$nonce || $nonce !== $account->get('oauthStateNonce')) {
            throw new RuntimeException('State validation failed.');
        }
    }

    public function extractAccountId(string $state): string
    {
        $payload = $this->decodeState($state);
        $accountId = $payload['accountId'] ?? null;
        if (!$accountId) {
            throw new RuntimeException('State account id missing.');
        }

        return (string) $accountId;
    }

    public function extractEntityType(string $state): string
    {
        $payload = $this->decodeState($state);
        $entityType = $payload['entityType'] ?? null;
        if (!$entityType) {
            return 'InboundEmail';
        }

        return (string) $entityType;
    }

    public function generatePkceCodeVerifier(Entity $account): string
    {
        $verifier = $this->randomString(64);
        $account->set('oauthCodeVerifier', $verifier);
        return $verifier;
    }

    public function buildPkceCodeChallenge(string $verifier): string
    {
        return $this->base64UrlEncode(hash('sha256', $verifier, true));
    }

    private function randomString(int $length): string
    {
        $bytes = random_bytes($length);
        return rtrim($this->base64UrlEncode($bytes), '=');
    }

    private function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private function base64UrlDecode(string $value): string
    {
        $value = strtr($value, '-_', '+/');
        $pad = strlen($value) % 4;
        if ($pad) {
            $value .= str_repeat('=', 4 - $pad);
        }
        return base64_decode($value);
    }

    private function decodeState(string $state): array
    {
        $decoded = $this->base64UrlDecode($state);
        $payload = json_decode($decoded, true);
        if (!is_array($payload)) {
            throw new RuntimeException('Invalid state payload.');
        }

        return $payload;
    }
}
