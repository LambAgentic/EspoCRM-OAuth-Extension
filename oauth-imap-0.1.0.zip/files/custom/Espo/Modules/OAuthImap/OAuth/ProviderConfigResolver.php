<?php

namespace Espo\Modules\OAuthImap\OAuth;

use Espo\ORM\Entity;
use Espo\Modules\OAuthImap\Models\OAuthProviderConfig;
use RuntimeException;

class ProviderConfigResolver
{
    /** @var array<string, array<string, mixed>> */
    private array $defaults;

    /**
     * @param array<string, array<string, mixed>> $defaults
     */
    public function __construct(array $defaults = [])
    {
        $this->defaults = $defaults;
    }

    public function resolveForAccount(Entity $account): OAuthProviderConfig
    {
        $provider = strtolower((string) $account->get('oauthProvider'));
        if (!$provider) {
            throw new RuntimeException('OAuth provider not set.');
        }

        $default = $this->defaults[$provider] ?? [];

        $clientId = (string) ($account->get('oauthClientId') ?: ($default['clientId'] ?? ''));
        $clientSecret = (string) ($account->get('oauthClientSecret') ?: ($default['clientSecret'] ?? ''));
        $tenantId = (string) ($account->get('oauthTenantId') ?: ($default['tenantId'] ?? ''));
        $redirectUri = (string) ($default['redirectUri'] ?? '');

        $accountScopesRaw = (string) $account->get('oauthScopes');
        $defaultScopesRaw = (string) ($default['scopes'] ?? '');
        $scopesRaw = trim($accountScopesRaw);
        if ($defaultScopesRaw !== '') {
            $scopesRaw = $scopesRaw === ''
                ? $defaultScopesRaw
                : ($scopesRaw . ' ' . $defaultScopesRaw);
        }
        $scopes = array_values(array_filter(preg_split('/[\s,]+/', $scopesRaw)));

        if ($provider === 'microsoft') {
            $scopes = $this->normalizeMicrosoftScopes($scopes);
        }

        if (!$clientId || !$clientSecret || !$redirectUri) {
            throw new RuntimeException('OAuth client configuration missing.');
        }

        return new OAuthProviderConfig(
            $provider,
            $clientId,
            $clientSecret,
            $redirectUri,
            $scopes,
            $tenantId ?: null
        );
    }

    /**
     * Ensure Outlook IMAP scope is fully qualified.
     *
     * @param string[] $scopes
     * @return string[]
     */
    private function normalizeMicrosoftScopes(array $scopes): array
    {
        $normalized = [];
        foreach ($scopes as $scope) {
            // Normalize legacy outlook.office365.com to outlook.office.com to avoid duplicates.
            if (stripos($scope, 'https://outlook.office365.com/') === 0) {
                $scope = 'https://outlook.office.com/' . substr($scope, strlen('https://outlook.office365.com/'));
            }
            if (strcasecmp($scope, 'IMAP.AccessAsUser.All') === 0) {
                $normalized[] = 'https://outlook.office.com/IMAP.AccessAsUser.All';
                continue;
            }
            if (strcasecmp($scope, 'outlook.office365.com/IMAP.AccessAsUser.All') === 0) {
                $normalized[] = 'https://outlook.office.com/IMAP.AccessAsUser.All';
                continue;
            }
            $normalized[] = $scope;
        }

        return array_values(array_unique($normalized));
    }
}
