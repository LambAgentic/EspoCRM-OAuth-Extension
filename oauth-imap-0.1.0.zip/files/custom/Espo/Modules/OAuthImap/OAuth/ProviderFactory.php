<?php

namespace Espo\Modules\OAuthImap\OAuth;

use Espo\Modules\OAuthImap\OAuth\Provider\GoogleProviderAdapter;
use Espo\Modules\OAuthImap\OAuth\Provider\MicrosoftProviderAdapter;
use Espo\Modules\OAuthImap\OAuth\Provider\OAuthProviderInterface;
use RuntimeException;

class ProviderFactory
{
    public function create(string $provider): OAuthProviderInterface
    {
        switch (strtolower($provider)) {
            case 'google':
                return new GoogleProviderAdapter();
            case 'microsoft':
                return new MicrosoftProviderAdapter();
            default:
                throw new RuntimeException('Unsupported OAuth provider: ' . $provider);
        }
    }
}
